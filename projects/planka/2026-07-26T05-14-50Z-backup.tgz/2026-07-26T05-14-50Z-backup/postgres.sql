--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE planka;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "planka" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: planka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE planka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE planka OWNER TO postgres;

\connect planka

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: archive; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archive (
    id bigint DEFAULT public.next_id() NOT NULL,
    from_model text NOT NULL,
    original_record_id bigint NOT NULL,
    original_record json NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.archive OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint NOT NULL,
    dirname text NOT NULL,
    filename text NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    image jsonb
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    role text NOT NULL,
    can_comment boolean
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint NOT NULL,
    cover_attachment_id bigint,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_due_date_completed boolean
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" double precision NOT NULL
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    action_id bigint NOT NULL,
    card_id bigint NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    name text NOT NULL,
    background jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    background_image jsonb
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text NOT NULL,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    http_only_token text
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" double precision NOT NULL
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    is_admin boolean NOT NULL,
    name text NOT NULL,
    username text,
    phone text,
    organization text,
    subscribe_to_own_cards boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    language text,
    password_changed_at timestamp without time zone,
    avatar jsonb,
    is_sso boolean NOT NULL
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at) FROM stdin;
1452865745099686941	1452865745032578076	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:44:53.284	\N
1452865885592093727	1452865885491430430	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:45:10.033	\N
1452865980777628705	1452865980114928672	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:45:21.38	\N
1452866043859960867	1452866043759297570	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:45:28.9	\N
1452866225708205093	1452866225674650660	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:45:50.578	\N
1452866277281367078	1452866043759297570	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-02-24 08:45:56.726	\N
1452867330311717933	1452867330278163500	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:48:02.258	\N
1452867478672639024	1452867478580364335	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:48:19.943	\N
1452867536033940530	1452867535991997489	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:48:26.781	\N
1452867715264939060	1452867715172664371	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:48:48.147	\N
1452867801172673590	1452867801080398901	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:48:58.388	\N
1452867871813141560	1452867871779587127	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:06.809	\N
1452867947117675578	1452867947008623673	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:15.786	\N
1452867980630164540	1452867980537889851	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:19.782	\N
1452868021432353854	1452868021348467773	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:24.645	\N
1452868097105986624	1452868097022100543	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:33.666	\N
1452868246481929282	1452868246398043201	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-24 08:49:51.473	\N
1454802921345516649	1454802921228076136	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-02-27 00:53:42.688	\N
1454850979370370163	1454850979278095474	1452651665172726785	createCard	{"list": {"id": "1454850890090415217", "name": "TODO"}}	2025-02-27 02:29:11.652	\N
1454851142663013492	1454850979278095474	1452651665172726785	commentCard	{"text": "Continentale"}	2025-02-27 02:29:31.117	\N
1454851366848562295	1454851366756287606	1452651665172726785	createCard	{"list": {"id": "1454850890090415217", "name": "TODO"}}	2025-02-27 02:29:57.843	\N
1454851498105111672	1454851366756287606	1452651665172726785	commentCard	{"text": "Johanniter-Unfall-Hilfe e. V."}	2025-02-27 02:30:13.488	\N
1454852184528127099	1454852184427463802	1452651665172726785	createCard	{"list": {"id": "1454850890090415217", "name": "Ausgaben"}}	2025-02-27 02:31:35.318	\N
1454852831969281148	1454852184427463802	1452651665172726785	commentCard	{"text": "http://docker.local:3002/#/document/search/tag:Nebenkostenabrechnung"}	2025-02-27 02:32:52.497	\N
1454853074517492861	1454851366756287606	1452651665172726785	commentCard	{"text": "ASB Arbeiter Samariter Bund"}	2025-02-27 02:33:21.412	\N
1454853585366942850	1454853585257890945	1452651665172726785	createCard	{"list": {"id": "1454853343691146368", "name": "Arbeit"}}	2025-02-27 02:34:22.311	\N
1454853686550332548	1454853686458057859	1452651665172726785	createCard	{"list": {"id": "1454853271012246655", "name": "Einkünfte"}}	2025-02-27 02:34:34.373	\N
1454854485623964806	1454854485540078725	1452651665172726785	createCard	{"list": {"id": "1454853343691146368", "name": "Arbeit"}}	2025-02-27 02:36:09.63	\N
1454854616561747079	1454854485540078725	1452651665172726785	commentCard	{"text": "Ausgaben bei bspw. Taxfix"}	2025-02-27 02:36:25.238	\N
1467098868469466252	1452868097022100543	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:03:33.808	\N
1467098895958934669	1452867947008623673	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:03:37.087	\N
1467098946106033294	1452867715172664371	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:03:43.065	\N
1467099079006749840	1467099078939640975	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:03:58.908	\N
1467099207729939601	1452865885491430430	1452651665172726785	moveCard	{"toList": {"id": "1452662366008247307", "name": "In Bearbeitung"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-03-16 00:04:14.252	\N
1467100003615900819	1467100003523626130	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:05:49.13	\N
1467101222958793876	1467100003523626130	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:08:14.485	\N
1467101281997816982	1467101281905542293	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 00:08:21.524	\N
1467269901583385761	1467269901491111072	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-03-16 05:43:22.546	\N
1467276815994193059	1467276815960638626	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-03-16 05:57:06.808	\N
1467821180407776421	1452867478580364335	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-03-16 23:58:40.101	\N
1488928343762928807	1454802921228076136	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-04-15 02:54:50.048	\N
1488928634939901097	1488928634856015016	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-04-15 02:55:24.762	\N
1493636127838438576	1493636127771329711	1452651665172726785	createCard	{"list": {"id": "1493635969671234734", "name": "Zum Ausprobieren"}}	2025-04-21 14:48:21.643	\N
1493636512800048306	1493636512707773617	1452651665172726785	createCard	{"list": {"id": "1493635969671234734", "name": "Zum Ausprobieren"}}	2025-04-21 14:49:07.537	\N
1493643922776261812	1493636512707773617	1452651665172726785	moveCard	{"toList": {"id": "1493643906317812915", "name": "Done"}, "fromList": {"id": "1493635969671234734", "name": "ToDos"}}	2025-04-21 15:03:50.875	\N
1495094604771361977	1495094604737807544	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "ToDo"}}	2025-04-23 15:06:05.645	\N
1495887336842462395	1495887336741799098	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-04-24 17:21:06.672	\N
1495903843467134141	1495903843366470844	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "ToDo"}}	2025-04-24 17:53:54.415	\N
1495905270067365058	1495905269958313153	1452651665172726785	createCard	{"list": {"id": "1495905200894903488", "name": "Papa"}}	2025-04-24 17:56:44.479	\N
1495906931481511108	1495906931447956675	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "ToDo"}}	2025-04-24 18:00:02.536	\N
1495907829096121542	1495094604737807544	1452651665172726785	moveCard	{"toList": {"id": "1495907783302710469", "name": "Änderungen"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-04-24 18:01:49.538	\N
1498245717955708104	1498245717855044807	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-04-27 23:26:47.609	\N
1498256614631670985	1452867980537889851	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-04-27 23:48:26.592	\N
1498256625796908234	1498245717855044807	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-04-27 23:48:27.925	\N
1545189491340215507	1545189491239552210	1452651665172726785	createCard	{"list": {"id": "1545189262247331025", "name": "Ideen"}}	2025-07-01 17:55:41.482	\N
1545217220538270933	1545217220420830420	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:50:47.061	\N
1545217253329339606	1488928634856015016	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:50:50.97	\N
1545217263160788183	1452865885491430430	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662366008247307", "name": "In Bearbeitung"}}	2025-07-01 18:50:52.142	\N
1545217279275304152	1452865745032578076	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:50:54.062	\N
1545217305506481369	1452866225674650660	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:50:57.19	\N
1545217353657091291	1545217353623536858	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:51:02.93	\N
1545217939735577821	1545217939626525916	1452651665172726785	createCard	{"list": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 18:52:12.795	\N
1545275674380469470	1545217353623536858	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 20:46:55.3	\N
1545275687911294175	1545217939626525916	1452651665172726785	moveCard	{"toList": {"id": "1452662456613602316", "name": "Fertig"}, "fromList": {"id": "1452662319485027338", "name": "TODO"}}	2025-07-01 20:46:56.915	\N
1545930909398598881	1545930909272769760	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:28:45.403	\N
1545931664339764451	1545931664247489762	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:30:15.399	\N
1545934635182064868	1545930909272769760	1452651665172726785	moveCard	{"toList": {"id": "1495907783302710469", "name": "Änderungen"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:36:09.549	\N
1545934698683827429	1545931664247489762	1452651665172726785	moveCard	{"toList": {"id": "1495907783302710469", "name": "Änderungen"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:36:17.121	\N
1545934842170967271	1495903843366470844	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:36:34.224	\N
1545934880649512168	1495906931447956675	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-07-02 18:36:38.813	\N
1545965087724930281	1495094604737807544	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495907783302710469", "name": "Änderungen"}}	2025-07-02 19:36:39.775	\N
1545965341849421035	1545965341757146346	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-07-02 19:37:10.071	\N
1547281619704874221	1547281619587433708	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-07-04 15:12:22.619	\N
1551736327261652207	1551736327160988910	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2025-07-10 18:43:05.142	\N
1563548982150431989	1563548982041380084	1452651665172726785	createCard	{"list": {"id": "1563548876982453491", "name": "Von A nach B"}}	2025-07-27 01:52:43.338	\N
1564161071554495737	1564161071470609656	1452651665172726785	createCard	{"list": {"id": "1563548876982453491", "name": "Von A nach B"}}	2025-07-27 22:08:50.081	\N
1590105320787543292	1545965341757146346	1452651665172726785	moveCard	{"toList": {"id": "1452663143976141846", "name": "Fertig"}, "fromList": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:15:25.601	\N
1590105355868701949	1495887336741799098	1452651665172726785	moveCard	{"toList": {"id": "1452663143976141846", "name": "Fertig"}, "fromList": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:15:29.783	\N
1590105516510545151	1590105516418270462	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:15:48.933	\N
1590105640729052417	1590105640636777728	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:16:03.741	\N
1590113593515312387	1590113593439814914	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:31:51.786	\N
1590114143145297157	1590114143027856644	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "Änderungen"}}	2025-09-01 17:32:57.308	\N
1590114559933285639	1590114559899731206	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "Änderungen"}}	2025-09-01 17:33:46.993	\N
1590115031431775497	1590115031373055240	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "Änderungen"}}	2025-09-01 17:34:43.199	\N
1590115842861827341	1590115842752775436	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "Änderungen"}}	2025-09-01 17:36:19.93	\N
1590118928049243409	1590118927931802896	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-09-01 17:42:27.713	\N
1590118979328804115	1590118979295249682	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-09-01 17:42:33.826	\N
1590120287515444501	1590120287414781204	1452651665172726785	createCard	{"list": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-09-01 17:45:09.774	\N
1590120722028561691	1590105516418270462	1452651665172726785	moveCard	{"toList": {"id": "1495907783302710469", "name": "Änderungen"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-09-01 17:46:01.57	\N
1590120742723257628	1590120287414781204	1452651665172726785	moveCard	{"toList": {"id": "1495907783302710469", "name": "Änderungen"}, "fromList": {"id": "1495094480175367351", "name": "Beiträge"}}	2025-09-01 17:46:04.039	\N
1590122858439247147	1590122858346972458	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 17:50:16.252	\N
1590126459777713458	1590126459702215985	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-09-01 17:57:25.565	\N
1590138030201505080	1590138030151173431	1452651665172726785	createCard	{"list": {"id": "1452663766914171929", "name": "TODO"}}	2025-09-01 18:20:24.866	\N
1590138671779022138	1590138671737079097	1452651665172726785	createCard	{"list": {"id": "1452663766914171929", "name": "TODO"}}	2025-09-01 18:21:41.349	\N
1590158123618796866	1590158123518133569	1452651665172726785	createCard	{"list": {"id": "1452663077236376596", "name": "TODO"}}	2025-09-01 19:00:20.188	\N
1594383701322499396	1590138671737079097	1452651665172726785	moveCard	{"toList": {"id": "1452663850364044315", "name": "Fertig"}, "fromList": {"id": "1452663766914171929", "name": "TODO"}}	2025-09-07 14:55:48.28	\N
1594388703315232069	1590120287414781204	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-09-07 15:05:44.586	\N
1698803930986710532	1698803930944767491	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:40:09.697	\N
1594392628026148166	1590115842752775436	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-09-07 15:13:32.449	\N
1594393005354124615	1590105516418270462	1452651665172726785	moveCard	{"toList": {"id": "1545934746901546214", "name": "fertig"}, "fromList": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-09-07 15:14:17.43	\N
1612741746951718223	1612741746901386574	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:49:57.881	\N
1612741999046165843	1612741998945502546	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:50:27.934	\N
1612742277631837527	1612742277539562838	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:51:01.144	\N
1612742949961991517	1612742949911659868	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:52:21.292	\N
1612743097005901152	1612743096787797343	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:52:38.821	\N
1612743494248432995	1612743494147769698	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:53:26.176	\N
1612744486973080937	1612744486931137896	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:55:24.517	\N
1612744929816085869	1612744929782531436	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:56:17.309	\N
1612745255830947185	1612745255789004144	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:56:56.172	\N
1612746521093080438	1612746521000805749	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 22:59:27.004	\N
1612755115230365053	1612755115070981500	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 23:16:31.499	\N
1612764446734681488	1612764446684349839	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 23:35:03.907	\N
1612765691067237784	1612765690983351703	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-02 23:37:32.243	\N
1612786389496104353	1612786389437384096	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2025-10-03 00:18:39.688	\N
1615031146268067238	1452867801080398901	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-10-06 02:38:35.527	\N
1615031170771191207	1452868021348467773	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-10-06 02:38:38.469	\N
1615031204652778920	1452868246398043201	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-10-06 02:38:42.508	\N
1615031226664486313	1467099078939640975	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-10-06 02:38:45.13	\N
1615031258406978986	1551736327160988910	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2025-10-06 02:38:48.916	\N
1615056370443224493	1615056370392892844	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:28:42.504	\N
1615057444428318127	1615057444327654830	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:30:50.533	\N
1615057862441043377	1615057862399100336	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:31:40.364	\N
1615058007438132659	1615058007396189618	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:31:57.649	\N
1615058060563187125	1615058060512855476	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:32:03.982	\N
1615058513145365943	1615058513069868470	1452651665172726785	createCard	{"list": {"id": "1467269769538307230", "name": "ToDo"}}	2025-10-06 03:32:57.934	\N
1615492797438100920	1590122858346972458	1452651665172726785	moveCard	{"toList": {"id": "1452663143976141846", "name": "Fertig"}, "fromList": {"id": "1452663077236376596", "name": "TODO"}}	2025-10-06 17:55:48.654	\N
1615502213466031546	1615502213398922681	1452651665172726785	createCard	{"list": {"id": "1452663766914171929", "name": "TODO"}}	2025-10-06 18:14:31.134	\N
1615507412196787650	1615507412146456001	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-10-06 18:24:50.871	\N
1615517461648508356	1615517461514290627	1452651665172726785	createCard	{"list": {"id": "1452663766914171929", "name": "TODO"}}	2025-10-06 18:44:48.858	\N
1615543573153842630	1615543573019624901	1452651665172726785	createCard	{"list": {"id": "1495907783302710469", "name": "ToDo's"}}	2025-10-06 19:36:41.593	\N
1626063269519164879	1626063269418501582	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-21 07:57:27.123	\N
1626065616584574418	1626065616492299729	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-21 08:02:06.915	\N
1626069874314839509	1626069874222564820	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-21 08:10:34.476	\N
1626110453652391384	1626110453551728087	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-21 09:31:11.909	\N
1626753692097054172	1626753691996390875	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-22 06:49:11.908	\N
1626753747923240414	1626753747830965725	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-22 06:49:18.563	\N
1627324853935670752	1627324853893727711	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-10-23 01:43:59.705	\N
1639417119164597732	1639417119122654691	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-11-08 18:09:10.052	\N
1639417271904372198	1639417271812097509	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2025-11-08 18:09:28.26	\N
1639438960197371367	1639417271812097509	1452651665172726785	moveCard	{"toList": {"id": "1626063201621771725", "name": "Erledigt"}, "fromList": {"id": "1626063161415173580", "name": "ToDos"}}	2025-11-08 18:52:33.704	\N
1688436908385895917	1688436908343952876	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-01-15 09:22:44.299	\N
1688437641575400943	1688437641533457902	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-01-15 09:24:11.701	\N
1688442986645423601	1688442986603480560	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-01-15 09:34:48.884	\N
1698803585745159670	1698803585703216629	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:28.542	\N
1698803648919766520	1698803648793937399	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:36.073	\N
1698803696290235898	1698803696189572601	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:41.719	\N
1698803742444357116	1698803742360471035	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:47.222	\N
1698803786199336446	1698803786149004797	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:52.436	\N
1698803837269181952	1698803837227238911	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:39:58.526	\N
1698803887114290690	1698803887063959041	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:40:04.468	\N
1698803976276805126	1698803976234862085	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:40:15.097	\N
1698804027371816456	1698804027287930375	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:40:21.188	\N
1698804090546423306	1698804090487703049	1452651665172726785	createCard	{"list": {"id": "1698778097521788404", "name": "4 Wochen"}}	2026-01-29 16:40:28.719	\N
1698804246113158669	1698804245995718156	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:40:47.263	\N
1698804398643217935	1698804398542554638	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:05.446	\N
1698804438791095825	1698804438707209744	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:10.233	\N
1698804482965505555	1698804482881619474	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:15.499	\N
1698804608517801493	1698804608232588820	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:30.465	\N
1698804657901536791	1698804657809262102	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:36.353	\N
1698804710288393753	1698804710196119064	1452651665172726785	createCard	{"list": {"id": "1698804175724348939", "name": "3 Wochen"}}	2026-01-29 16:41:42.598	\N
1698804821068351004	1698804821034796571	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:41:55.804	\N
1698804864085132830	1698804863992858141	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:00.932	\N
1698804913460479520	1698804913359816223	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:06.817	\N
1698804969009841698	1698804968917567009	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:13.44	\N
1698805012764821028	1698805012680934947	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:18.656	\N
1698805065797600806	1698805065705326117	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:24.978	\N
1698805120155780648	1698805120046728743	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:31.458	\N
1698805166980990506	1698805166947436073	1452651665172726785	createCard	{"list": {"id": "1698804761484068378", "name": "2 Wochen"}}	2026-01-29 16:42:37.04	\N
1698805428537787949	1698805428420347436	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:08.22	\N
1698805472804472367	1698805472770917934	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:13.497	\N
1698805518245561905	1698805518203618864	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:18.914	\N
1698805559886612019	1698805559844668978	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:23.878	\N
1698805610461529653	1698805610427975220	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:29.907	\N
1698805722667550263	1698805722600441398	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:43.283	\N
1698805771195647545	1698805771103372856	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:49.068	\N
1698805837692143163	1698805837599868474	1452651665172726785	createCard	{"list": {"id": "1698805297876829739", "name": "1 Woche vor dem Umzug"}}	2026-01-29 16:43:56.995	\N
1698806276575725123	1698806276533782082	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:44:49.314	\N
1698806320607528517	1698806320515253828	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:44:54.563	\N
1698806370779792967	1698806370695906886	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:45:00.544	\N
1698806415935669833	1698806415851783752	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:45:05.927	\N
1698806454321940043	1698806454288385610	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:45:10.503	\N
1698806497959478861	1698806497867204172	1452651665172726785	createCard	{"list": {"id": "1698805887235262012", "name": "3 Tage vor dem Umzug"}}	2026-01-29 16:45:15.705	\N
1698806541982893647	1698806541940950606	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:20.952	\N
1698806580025230929	1698806579983287888	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:25.487	\N
1698806617035769427	1698806616993826386	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:29.9	\N
1698806676443891285	1698806675009439316	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:36.982	\N
1698806717606790743	1698806717564847702	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:41.888	\N
1698806763232429657	1698806763198875224	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:47.328	\N
1698806800075195995	1698806799982921306	1452651665172726785	createCard	{"list": {"id": "1698805928733705789", "name": "1 Tag vor dem Umzug"}}	2026-01-29 16:45:51.72	\N
1698806863350466141	1698806863266580060	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:45:59.263	\N
1698806901468300895	1698806901376026206	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:03.808	\N
1698807025435149921	1698807025351263840	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:18.585	\N
1698807073669645923	1698807073577371234	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:24.334	\N
1698807117718226533	1698807117676283492	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:29.586	\N
1698807156758808167	1698807156658144870	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:34.24	\N
1698807203349137001	1698807203307193960	1452651665172726785	createCard	{"list": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 16:46:39.794	\N
1698807251684296299	1698807251592021610	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:46:45.556	\N
1698807301688788589	1698807301596513900	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:46:51.517	\N
1698807350577596015	1698807350493709934	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:46:57.345	\N
1698807397788681841	1698807397679629936	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:47:02.972	\N
1698807446409053811	1698807446375499378	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:47:08.769	\N
1698807491455878773	1698807491422324340	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:47:14.139	\N
1698807536821470839	1698807536762750582	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:47:19.547	\N
1698807612797093497	1698807612755150456	1452651665172726785	createCard	{"list": {"id": "1698806018860910143", "name": "1–2 Tage nach dem Umzug"}}	2026-01-29 16:47:28.604	\N
1698807672683366011	1698807672599479930	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:47:35.743	\N
1698807767139092093	1698807767105537660	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:47:47.003	\N
1698807820113151615	1698807820020876926	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:47:53.318	\N
1698807873187874433	1698807873154320000	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:47:59.645	\N
1698807910492014211	1698807910374573698	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:48:04.092	\N
1698807971603023493	1698807971561080452	1452651665172726785	createCard	{"list": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 16:48:11.376	\N
1698808036019144327	1698808035926869638	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:19.056	\N
1698808084362692233	1698808084152977032	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:24.819	\N
1698808130709751435	1698808130676197002	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:30.344	\N
1698808169498674829	1698808169465120396	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:34.968	\N
1698808224184010383	1698808224083347086	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:41.486	\N
1698808267091740305	1698808267058185872	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:46.602	\N
1698808305972938387	1698808305889052306	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:51.237	\N
1698808349342041749	1698808349249767060	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:48:56.407	\N
1698808388877551255	1698808388793665174	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:49:01.12	\N
1698808430015284889	1698808429931398808	1452651665172726785	createCard	{"list": {"id": "1698806181969004097", "name": "Essentials- / Notfallbox (unbedingt persönlich transportieren)"}}	2026-01-29 16:49:06.024	\N
1698808575423415964	1698808575389861531	1452651665172726785	createCard	{"list": {"id": "1698808525116933786", "name": "Übergabeprotokoll — kurz (alte Wohnung)"}}	2026-01-29 16:49:23.359	\N
1698808620495406750	1698808620453463709	1452651665172726785	createCard	{"list": {"id": "1698808525116933786", "name": "Übergabeprotokoll — kurz (alte Wohnung)"}}	2026-01-29 16:49:28.731	\N
1698808660517455520	1698808660458735263	1452651665172726785	createCard	{"list": {"id": "1698808525116933786", "name": "Übergabeprotokoll — kurz (alte Wohnung)"}}	2026-01-29 16:49:33.501	\N
1698808715253122722	1698808715202791073	1452651665172726785	createCard	{"list": {"id": "1698808525116933786", "name": "Übergabeprotokoll — kurz (alte Wohnung)"}}	2026-01-29 16:49:40.028	\N
1698808754897684132	1698808754755077795	1452651665172726785	createCard	{"list": {"id": "1698808525116933786", "name": "Übergabeprotokoll — kurz (alte Wohnung)"}}	2026-01-29 16:49:44.753	\N
1698814284642911909	1698807873154320000	1452651665172726785	moveCard	{"toList": {"id": "1698805970097931838", "name": "Umzugstag"}, "fromList": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}}	2026-01-29 17:00:43.948	\N
1698814339512796838	1698807873154320000	1452651665172726785	moveCard	{"toList": {"id": "1698806081490257472", "name": "1–2 Wochen nach dem Umzug"}, "fromList": {"id": "1698805970097931838", "name": "Umzugstag"}}	2026-01-29 17:00:50.491	\N
1698814492445509289	1698814492411954856	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:08.722	\N
1698814535705560747	1698814535613286058	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:13.879	\N
1698814577271113389	1698814577170450092	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:18.833	\N
1698814616261363375	1698814616177477294	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:23.482	\N
1698814662088328881	1698814661870225072	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:28.944	\N
1698814712629692083	1698814712545806002	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:34.97	\N
1698814755445147317	1698814755361261236	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:40.074	\N
1698814807353853623	1698814807269967542	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:46.262	\N
1698814875486127801	1698814875393853112	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:01:54.384	\N
1698814924458821307	1698814924425266874	1452651665172726785	createCard	{"list": {"id": "1698814380986074791", "name": "Umzug"}}	2026-01-29 17:02:00.222	\N
1698819321549031193	1698819321448367896	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:10:44.396	\N
1698819368760117019	1698819368651065114	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:10:50.024	\N
1698819412129220381	1698819411844007708	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:10:55.193	\N
1698819456093914911	1698819456060360478	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:11:00.435	\N
1698819502701020961	1698819502617134880	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:11:05.991	\N
1698819564491507491	1698819564441175842	1452651665172726785	createCard	{"list": {"id": "1698819234039072535", "name": "Wichtige Adressen"}}	2026-01-29 17:11:13.355	\N
1698819746507523878	1698819746423637797	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:11:35.055	\N
1698819793383065384	1698819793332733735	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:11:40.643	\N
1698819833975539498	1698819833941985065	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:11:45.482	\N
1698819883342497580	1698819883258611499	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:11:51.367	\N
1698819924522174254	1698819924404733741	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:11:56.276	\N
1698819992872552240	1698819992830609199	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:12:04.423	\N
1698820037869045554	1698820037827102513	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:12:09.788	\N
1698820082211227444	1698820082110564147	1452651665172726785	createCard	{"list": {"id": "1698819694028392228", "name": "Packtipps"}}	2026-01-29 17:12:15.073	\N
1698824790191638325	1452867535991997489	1452651665172726785	moveCard	{"toList": {"id": "1452867359294358574", "name": "Fertig"}, "fromList": {"id": "1452867259629306923", "name": "TODO"}}	2026-01-29 17:21:36.307	\N
1701033077834254135	1688436908343952876	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-01 18:29:04.709	\N
1701049384164132666	1701049384088635193	1452651665172726785	createCard	{"list": {"id": "1701049333362722616", "name": "Models"}}	2026-02-01 19:01:28.575	\N
1701049476631758652	1701049476497540923	1452651665172726785	createCard	{"list": {"id": "1701049333362722616", "name": "Models"}}	2026-02-01 19:01:39.597	\N
1701049702360811326	1701049702268536637	1452651665172726785	createCard	{"list": {"id": "1701049333362722616", "name": "Models"}}	2026-02-01 19:02:06.508	\N
1701050821367564096	1701050821325621055	1452651665172726785	createCard	{"list": {"id": "1701049333362722616", "name": "Models"}}	2026-02-01 19:04:19.904	\N
1701054700343789378	1701054700285069121	1452651665172726785	createCard	{"list": {"id": "1701049333362722616", "name": "Models"}}	2026-02-01 19:12:02.312	\N
1701764257177143108	1701764257126811459	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-02 18:41:48.079	\N
1701764354325612358	1701764354224949061	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-02 18:41:59.661	\N
1701764666323109704	1701764666281166663	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-02 18:42:36.854	\N
1701765700244211530	1701765700151936841	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-02 18:44:40.107	\N
1701969824730580811	1701764354224949061	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-03 01:30:13.641	\N
1701969846784231244	1701764666281166663	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-03 01:30:16.271	\N
1701969902442645325	1701764257126811459	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-02-03 01:30:22.906	\N
1702734949204887375	1702734949162944334	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 02:50:23.587	\N
1702735106264794961	1702735106147354448	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 02:50:42.31	\N
1702735470758201171	1702735470699480914	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 02:51:25.759	\N
1702846213067376470	1702735470699480914	1452651665172726785	moveCard	{"toList": {"id": "1626063201621771725", "name": "Erledigt"}, "fromList": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 06:31:27.27	\N
1702846229802649431	1702735106147354448	1452651665172726785	moveCard	{"toList": {"id": "1626063201621771725", "name": "Erledigt"}, "fromList": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 06:31:29.268	\N
1702846260915996504	1702734949162944334	1452651665172726785	moveCard	{"toList": {"id": "1626063201621771725", "name": "Erledigt"}, "fromList": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 06:31:32.976	\N
1702846675128682330	1702846675036407641	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-04 06:32:22.355	\N
1703443681865893724	1703443681823950683	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-05 02:18:31.104	\N
1703444047357544286	1703444047265269597	1452651665172726785	createCard	{"list": {"id": "1626063161415173580", "name": "ToDos"}}	2026-02-05 02:19:14.674	\N
1707198061811337056	1707198061735839583	1452651665172726785	createCard	{"list": {"id": "1612741563408975180", "name": "ToDos"}}	2026-02-10 06:37:48.07	\N
1747495946935076706	1688437641533457902	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:02:30.323	\N
1747495960709171043	1688442986603480560	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:02:31.968	\N
1747495985161963364	1701765700151936841	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:02:34.883	\N
1747496167026984806	1747496166926321509	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:02:56.563	\N
1747496341182875496	1747496341115766631	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:03:17.323	\N
1747496515674310506	1747496515582035817	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:03:38.125	\N
1747496790023735148	1747496789931460459	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:04:10.83	\N
1747497530913982318	1747497530813319021	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:05:39.151	\N
1747498088630585200	1747498088597030767	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-06 21:06:45.637	\N
1747590861962610545	1747498088597030767	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 00:11:05.077	\N
1747590904115365746	1747496789931460459	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 00:11:10.104	\N
1747590945060161395	1747496166926321509	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 00:11:14.985	\N
1747599887920269173	1747599887827994484	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 00:29:01.057	\N
1747611483283392375	1747611483182729078	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 00:52:03.332	\N
1747618012556429176	1747496341115766631	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 01:05:01.68	\N
1747618032110274425	1747496515582035817	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 01:05:04.014	\N
1747622187189143418	1747497530813319021	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 01:13:19.335	\N
1747642685012838268	1747642684920563579	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 01:54:02.868	\N
1747643657453832062	1747643657353168765	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 01:55:58.792	\N
1747658982039750528	1747658981947475839	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 02:26:25.625	\N
1747686178183710594	1747686178091435905	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 03:20:27.658	\N
1747717963928045443	1747686178091435905	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 04:23:36.812	\N
1747718035071829892	1747599887827994484	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 04:23:45.295	\N
1747790022683133830	1747790022632802181	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-07 06:46:46.887	\N
1748311891786073992	1748311891677022087	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 00:03:38.532	\N
1748312254828251018	1748312254777919369	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 00:04:21.81	\N
1748312581665195916	1748312581614864267	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 00:05:00.772	\N
1748344941450364813	1747642684920563579	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 01:09:18.358	\N
1748344992302106510	1747658981947475839	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 01:09:24.421	\N
1748345016620681103	1747790022632802181	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 01:09:27.32	\N
1748348714168092560	1748312254777919369	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 01:16:48.099	\N
1748356580149036945	1748311891677022087	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 01:32:25.798	\N
1748373451149674387	1748373451057399698	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 02:05:56.98	\N
1748419242748807060	1748373451057399698	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 03:36:55.762	\N
1748460654647314326	1748460654596982677	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 04:59:12.446	\N
1748514149085742999	1747643657353168765	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 06:45:29.479	\N
1748514155880515480	1747611483182729078	1452651665172726785	moveCard	{"toList": {"id": "1701033058792113974", "name": "Erledigt"}, "fromList": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-08 06:45:30.291	\N
1753404132560996255	1753404132326115230	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-04-15 00:41:00.937	\N
1753404195039348641	1753404194997405600	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-04-15 00:41:08.384	\N
1753404363339990947	1753404363256104866	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-04-15 00:41:28.448	\N
1753406163677874088	1753406163593988007	1452651665172726785	createCard	{"list": {"id": "1753405964557485990", "name": "Features"}}	2026-04-15 00:45:03.065	\N
1753406184120911786	1753406184037025705	1452651665172726785	createCard	{"list": {"id": "1753405964557485990", "name": "Features"}}	2026-04-15 00:45:05.502	\N
1753406413171853228	1753406413138298795	1452651665172726785	createCard	{"list": {"id": "1753405964557485990", "name": "Features"}}	2026-04-15 00:45:32.807	\N
1753406692160178094	1753406692101457837	1452651665172726785	createCard	{"list": {"id": "1753405964557485990", "name": "Features"}}	2026-04-15 00:46:06.065	\N
1753416783018067889	1753416782883850159	1452651665172726785	createCard	{"list": {"id": "1688436647122699755", "name": "ToDos"}}	2026-04-15 01:06:08.989	\N
1758946277845895092	1758946277720065970	1452651665172726785	createCard	{"list": {"id": "1452867259629306923", "name": "TODO"}}	2026-04-22 16:12:16.139	\N
1813357595776255930	1813357595616872376	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:57:50.693	\N
1813357650218321853	1813357650100881339	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:57:57.183	\N
1813358003479381952	1813358003395495870	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:58:39.295	\N
1813358258904106948	1813358258828609474	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:59:09.744	\N
1813358351807940551	1813358351740831685	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:59:20.819	\N
1813358441448605642	1813358441305999304	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:59:31.504	\N
1813358632725645261	1813358632423655371	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 17:59:54.307	\N
1813358839815210960	1813358839689381838	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Features"}}	2026-07-06 18:00:18.994	\N
1813360775528450018	1813357650100881339	1452651665172726785	moveCard	{"toList": {"id": "1813360670771513313", "name": "Erledigt"}, "fromList": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-06 18:04:09.749	\N
1813360809963685859	1813358351740831685	1452651665172726785	moveCard	{"toList": {"id": "1813360670771513313", "name": "Erledigt"}, "fromList": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-06 18:04:13.855	\N
1813360851034310628	1813357595616872376	1452651665172726785	moveCard	{"toList": {"id": "1813360670771513313", "name": "Erledigt"}, "fromList": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-06 18:04:18.749	\N
1813362423554377703	1813362423428548581	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-06 18:07:26.209	\N
1813552262476204013	1753404132326115230	1452651665172726785	moveCard	{"toList": {"id": "1813360670771513313", "name": "Erledigt"}, "fromList": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-07 00:24:36.77	\N
1814196222978689008	1814196222852859886	1452651665172726785	createCard	{"list": {"id": "1753404002411743133", "name": "Pipeline"}}	2026-07-07 21:44:02.846	\N
1823212639015143414	1823212638931257332	1452651665172726785	createCard	{"list": {"id": "1452663766914171929", "name": "TODO"}}	2026-07-20 08:18:03.396	\N
\.


--
-- Data for Name: archive; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.archive (id, from_model, original_record_id, original_record, created_at, updated_at) FROM stdin;
1452662941131211793	board	1452662910303077391	{"id":"1452662910303077391","createdAt":"2025-02-24T02:01:53.490Z","updatedAt":null,"position":65535,"name":"TODO","projectId":"1452662711828612109"}	2025-02-24 02:01:57.167	\N
1590105280773883131	list	1452663113743598613	{"id":"1452663113743598613","createdAt":"2025-02-24T02:02:17.745Z","updatedAt":null,"position":131070,"name":"In Bearbeitung","boardId":"1452663050141172754"}	2025-09-01 17:15:20.792	\N
1590115179532649738	card	1590113593439814914	{"id":"1590113593439814914","createdAt":"2025-09-01T17:31:51.776Z","updatedAt":"2025-09-01T17:32:06.199Z","position":196605,"name":"Fotos Vorstand aktualisieren","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1452663050141172754","listId":"1452663077236376596","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:35:00.852	\N
1590115202106393867	card	1590105640636777728	{"id":"1590105640636777728","createdAt":"2025-09-01T17:16:03.728Z","updatedAt":null,"position":131070,"name":"Hallenpläne ab 1.10 wieder neu","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1452663050141172754","listId":"1452663077236376596","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:35:03.546	\N
1590120536137008409	card	1590118979295249682	{"id":"1590118979295249682","createdAt":"2025-09-01T17:42:33.820Z","updatedAt":null,"position":196605,"name":"Tim Fabian","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1495094452761396405","listId":"1495094480175367351","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:45:39.411	\N
1590120559826437402	card	1590118927931802896	{"id":"1590118927931802896","createdAt":"2025-09-01T17:42:27.697Z","updatedAt":null,"position":131070,"name":"Jonas Hinze","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1495094452761396405","listId":"1495094480175367351","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:45:42.236	\N
1590120760515495197	list	1495094480175367351	{"id":"1495094480175367351","createdAt":"2025-04-23T15:05:50.793Z","updatedAt":"2025-04-24T18:01:33.160Z","position":65535,"name":"Beiträge","boardId":"1495094452761396405"}	2025-09-01 17:46:06.16	\N
1590121788237415716	card	1545930909272769760	{"id":"1545930909272769760","createdAt":"2025-07-02T18:28:45.386Z","updatedAt":"2025-07-02T18:36:09.536Z","position":131070,"name":"Zumba Angebot entfernen","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1495094452761396405","listId":"1495907783302710469","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:48:08.674	\N
1590122529362543912	card	1590114559899731206	{"id":"1590114559899731206","createdAt":"2025-09-01T17:33:46.984Z","updatedAt":null,"position":262140,"name":"Turnen mit Unterkategorien anlegen","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1495094452761396405","listId":"1495907783302710469","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:49:37.021	\N
1590122555711161641	card	1590115031373055240	{"id":"1590115031373055240","createdAt":"2025-09-01T17:34:43.191Z","updatedAt":null,"position":327675,"name":"Völkerball Fotos ergänzen","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1495094452761396405","listId":"1495907783302710469","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 17:49:40.164	\N
1590126639646246197	action	1590126586336642356	{"id":"1590126586336642356","createdAt":"2025-09-01T17:57:40.649Z","updatedAt":null,"type":"commentCard","data":{"text":"Info an Mathias"},"cardId":"1590126459702215985","userId":"1452651665172726785"}	2025-09-01 17:57:47.006	\N
1590140529385932093	list	1452663832353702938	{"id":"1452663832353702938","createdAt":"2025-02-24T02:03:43.410Z","updatedAt":null,"position":131070,"name":"In Bearbeitung","boardId":"1452663196799206423"}	2025-09-01 18:25:22.789	\N
1590140567763813694	card	1590138030151173431	{"id":"1590138030151173431","createdAt":"2025-09-01T18:20:24.859Z","updatedAt":null,"position":65535,"name":"Jonas","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1452663196799206423","listId":"1452663766914171929","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2025-09-01 18:25:27.368	\N
1612771522525529501	task	1612741831408223568	{"id":"1612741831408223568","createdAt":"2025-10-02T22:50:07.950Z","updatedAt":null,"position":65535,"name":"Filter hinzufügen","isCompleted":false,"cardId":"1612741746901386574"}	2025-10-02 23:49:07.406	\N
1612771542641411486	task	1612741854082630993	{"id":"1612741854082630993","createdAt":"2025-10-02T22:50:10.653Z","updatedAt":null,"position":131070,"name":"Tabelle anpassen","isCompleted":false,"cardId":"1612741746901386574"}	2025-10-02 23:49:09.805	\N
1698818377998403331	list	1698778097521788404	{"id":"1698778097521788404","createdAt":"2026-01-29T15:48:50.107Z","updatedAt":"2026-01-29T16:43:01.509Z","position":65535,"name":"4 Wochen vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:08:51.911	\N
1698818397854238468	list	1698804175724348939	{"id":"1698804175724348939","createdAt":"2026-01-29T16:40:38.869Z","updatedAt":"2026-01-29T16:42:59.777Z","position":131070,"name":"3 Wochen vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:08:54.283	\N
1698818415847802629	list	1698804761484068378	{"id":"1698804761484068378","createdAt":"2026-01-29T16:41:48.701Z","updatedAt":"2026-01-29T16:42:58.195Z","position":196605,"name":"2 Wochen vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:08:56.428	\N
1698818434847999750	list	1698805297876829739	{"id":"1698805297876829739","createdAt":"2026-01-29T16:42:52.643Z","updatedAt":null,"position":262140,"name":"1 Woche vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:08:58.693	\N
1698818451264505607	list	1698805887235262012	{"id":"1698805887235262012","createdAt":"2026-01-29T16:44:02.901Z","updatedAt":null,"position":327675,"name":"3 Tage vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:09:00.65	\N
1698818470340200200	list	1698805928733705789	{"id":"1698805928733705789","createdAt":"2026-01-29T16:44:07.849Z","updatedAt":null,"position":393210,"name":"1 Tag vor dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:09:02.924	\N
1698818532222961417	list	1698805970097931838	{"id":"1698805970097931838","createdAt":"2026-01-29T16:44:12.779Z","updatedAt":null,"position":458745,"name":"Umzugstag","boardId":"1698777948523333106"}	2026-01-29 17:09:10.301	\N
1698819006430971668	list	1698806018860910143	{"id":"1698806018860910143","createdAt":"2026-01-29T16:44:18.592Z","updatedAt":null,"position":524280,"name":"1–2 Tage nach dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:10:06.829	\N
1698819028912441109	list	1698806081490257472	{"id":"1698806081490257472","createdAt":"2026-01-29T16:44:26.057Z","updatedAt":null,"position":589815,"name":"1–2 Wochen nach dem Umzug","boardId":"1698777948523333106"}	2026-01-29 17:10:09.511	\N
1698819047216383766	list	1698806181969004097	{"id":"1698806181969004097","createdAt":"2026-01-29T16:44:38.035Z","updatedAt":null,"position":655350,"name":"Essentials- / Notfallbox (unbedingt persönlich transportieren)","boardId":"1698777948523333106"}	2026-01-29 17:10:11.693	\N
1813359354288539605	label	1813358075034208193	{"id":"1813358075034208193","createdAt":"2026-07-06T17:58:47.823Z","updatedAt":null,"position":65535,"name":null,"color":"orange-peel","boardId":"1753403814414649243"}	2026-07-06 18:01:20.324	\N
1813359931114391515	card	1813358441305999304	{"id":"1813358441305999304","createdAt":"2026-07-06T17:59:31.486Z","updatedAt":null,"position":589815,"name":"Zuordnung zur Versicherungen","description":null,"dueDate":null,"isDueDateCompleted":null,"stopwatch":null,"boardId":"1753403814414649243","listId":"1753404002411743133","creatorUserId":"1452651665172726785","coverAttachmentId":null}	2026-07-06 18:02:29.085	\N
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, dirname, filename, name, created_at, updated_at, image) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, created_at, updated_at) FROM stdin;
1452662097665065992	1452661474173387782	65535	Aufgaben	2025-02-24 02:00:16.617	2025-02-24 02:00:34.116
1452663050141172754	1452662711828612109	65535	Vorstand	2025-02-24 02:02:10.161	\N
1452663196799206423	1452662711828612109	131070	Mein TSV	2025-02-24 02:02:27.646	\N
1452867106646262825	1452866590914642983	65535	Aufgaben	2025-02-24 08:47:35.592	2025-02-24 08:50:23.886
1454850282016998511	1452866590914642983	131070	Steuererklärung	2025-02-27 02:27:48.52	\N
1467269675300684956	1467269614944650394	65535	Board	2025-03-16 05:42:55.571	2025-03-16 05:43:02.921
1493635838540514476	1493635767044408490	65535	Rainbow Six Siege	2025-04-21 14:47:47.158	\N
1495094452761396405	1452662711828612109	196605	Homepage	2025-04-23 15:05:47.521	\N
1495905149799892158	1452866590914642983	196605	Geschenkideen	2025-04-24 17:56:30.14	\N
1545189208367301839	1545189120085591245	65535	Growbox	2025-07-01 17:55:07.748	\N
1563548678239552753	1493635767044408490	131070	WoW	2025-07-27 01:52:07.11	\N
1590123339425252652	1452662711828612109	262140	Badminton	2025-09-01 17:51:13.589	\N
1612741356319409482	1612741231933130056	65535	Git Projekt	2025-10-02 22:49:11.313	2025-10-02 22:49:32.779
1626063126602450378	1626062972277229000	65535	Projekt	2025-10-21 07:57:10.085	\N
1688436604735063529	1452662711828612109	327675	Fördertafel	2026-01-15 09:22:08.099	\N
1698777948523333106	1452866590914642983	262140	Umzug	2026-01-29 15:48:32.329	\N
1753403814414649243	1753403700707067801	65535	Wohnungsverwaltung	2026-04-15 00:40:23.01	2026-04-15 00:40:38.08
1753405936656975780	1753403700707067801	131070	Projektverwaltung	2026-04-15 00:44:36	\N
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, board_id, user_id, created_at, updated_at, role, can_comment) FROM stdin;
1452662097707009033	1452662097665065992	1452651665172726785	2025-02-24 02:00:16.624	\N	editor	\N
1452663050225058835	1452663050141172754	1452651665172726785	2025-02-24 02:02:10.173	\N	editor	\N
1452663196824372248	1452663196799206423	1452651665172726785	2025-02-24 02:02:27.649	\N	editor	\N
1452867106738537514	1452867106646262825	1452651665172726785	2025-02-24 08:47:35.604	\N	editor	\N
1454850282050552944	1454850282016998511	1452651665172726785	2025-02-27 02:27:48.526	\N	editor	\N
1467269675334239389	1467269675300684956	1452651665172726785	2025-03-16 05:42:55.575	\N	editor	\N
1493635838616011949	1493635838540514476	1452651665172726785	2025-04-21 14:47:47.168	\N	editor	\N
1495094452803339446	1495094452761396405	1452651665172726785	2025-04-23 15:05:47.529	\N	editor	\N
1495905149841835199	1495905149799892158	1452651665172726785	2025-04-24 17:56:30.147	\N	editor	\N
1545189208459576528	1545189208367301839	1452651665172726785	2025-07-01 17:55:07.761	\N	editor	\N
1563548678289884402	1563548678239552753	1452651665172726785	2025-07-27 01:52:07.115	\N	editor	\N
1590123339559470381	1590123339425252652	1452651665172726785	2025-09-01 17:51:13.604	\N	editor	\N
1612741356411684171	1612741356319409482	1452651665172726785	2025-10-02 22:49:11.325	\N	editor	\N
1626063126694725067	1626063126602450378	1452651665172726785	2025-10-21 07:57:10.097	\N	editor	\N
1688436604835726826	1688436604735063529	1452651665172726785	2026-01-15 09:22:08.112	\N	editor	\N
1698777948573664755	1698777948523333106	1452651665172726785	2026-01-29 15:48:32.352	\N	editor	\N
1753403814464980892	1753403814414649243	1452651665172726785	2026-04-15 00:40:23.017	\N	editor	\N
1753405936690530213	1753405936656975780	1452651665172726785	2026-04-15 00:44:36.007	\N	editor	\N
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, cover_attachment_id, "position", name, description, due_date, stopwatch, created_at, updated_at, is_due_date_completed) FROM stdin;
1452867947008623673	1452867106646262825	1452867359294358574	1452651665172726785	\N	32767.5	Ablage abheften	\N	\N	\N	2025-02-24 08:49:15.773	2025-10-06 02:39:20.596	\N
1452868097022100543	1452867106646262825	1452867359294358574	1452651665172726785	\N	163837.5	Zahnarzt-Termine verlegen	\N	\N	\N	2025-02-24 08:49:33.656	2025-10-06 02:39:20.602	\N
1452865980114928672	1452662097665065992	1452662319485027338	1452651665172726785	\N	196605	Profilbild bei Facebook ändern	\N	\N	\N	2025-02-24 08:45:21.299	\N	\N
1452867980537889851	1452867106646262825	1452867359294358574	1452651665172726785	\N	61439.0625	Fenster putzen	\N	\N	\N	2025-02-24 08:49:19.77	2025-10-06 02:39:20.618	\N
1701049476497540923	1688436604735063529	1701049333362722616	1452651665172726785	\N	131070	Customer	\N	\N	\N	2026-02-01 19:01:39.58	\N	\N
1452866043759297570	1452662097665065992	1452662456613602316	1452651665172726785	\N	65535	Flyer online stellen	\N	\N	\N	2025-02-24 08:45:28.887	2025-02-24 08:45:56.699	\N
1547281619587433708	1452867106646262825	1452867259629306923	1452651665172726785	\N	65535	Netflix über Sky?	\N	\N	\N	2025-07-04 15:12:22.602	2025-10-06 02:39:26.701	\N
1452867871779587127	1452867106646262825	1452867259629306923	1452651665172726785	\N	393210	Sachen bei eBay reinstellen	\N	\N	\N	2025-02-24 08:49:06.805	2025-10-06 02:39:26.702	\N
1467101281905542293	1452867106646262825	1452867259629306923	1452651665172726785	\N	917490	Strom und Gas	\N	\N	\N	2025-03-16 00:08:21.514	2025-10-06 02:39:26.705	\N
1452867330278163500	1452867106646262825	1452867259629306923	1452651665172726785	\N	983025	unnütze Verträge kündigen	\N	\N	\N	2025-02-24 08:48:02.254	2025-10-06 02:39:26.707	\N
1590122858346972458	1452663050141172754	1452663143976141846	1452651665172726785	\N	49151.25	Laptop vorbereiten	\N	\N	\N	2025-09-01 17:50:16.239	2025-10-06 17:55:48.641	\N
1626063269418501582	1626063126602450378	1626063161415173580	1452651665172726785	\N	65535	Anfragen	\N	\N	\N	2025-10-21 07:57:27.111	\N	\N
1626069874222564820	1626063126602450378	1626063161415173580	1452651665172726785	\N	196605	Location	\N	\N	\N	2025-10-21 08:10:34.464	2025-10-21 08:10:38.967	\N
1626753691996390875	1626063126602450378	1626063161415173580	1452651665172726785	\N	327675	Übersetzungen	\N	\N	\N	2025-10-22 06:49:11.894	\N	\N
1626753747830965725	1626063126602450378	1626063161415173580	1452651665172726785	\N	393210	FAQ	\N	\N	\N	2025-10-22 06:49:18.551	\N	\N
1467276815960638626	1467269675300684956	1467269769538307230	1452651665172726785	\N	131070	Kassen Typen	**Einfache Liste (Incremental) - Bierkasse**\n* jeder Spieler eines Teams hat eine Bilanz -/+ 0\n* Werte können definiert (max 5)\n\t* nur negative Werte festlegen -> dazu werden dann automatisch die positiven werden mit generiert damit man wieder auf 0 kommt\n* die definierten Werte werden in einer eigenen View als Buttons zur Verfügung gestellt\n\n**Katalog (catalog) - Strafenkasse**\n* im Katalog können Einträge definiert werden die dann zur Auswahl stehen\n* jeder Spieler eines Teams hat eine Bilanz -/+ 0\n* jeder Eintrag hat eine Beschreibung des hinterlegten Vergehens\n* Einträge können als bezahlt markiert werden	\N	\N	2025-03-16 05:57:06.802	2025-03-16 06:12:34.575	\N
1698808575389861531	1698777948523333106	1698808525116933786	1452651665172726785	\N	65535	Datum & Uhrzeit	\N	\N	\N	2026-01-29 16:49:23.354	\N	\N
1454850979278095474	1454850282016998511	1454850890090415217	1452651665172726785	\N	65535	Riester Rente	\N	\N	\N	2025-02-27 02:29:11.639	\N	\N
1454851366756287606	1454850282016998511	1454850890090415217	1452651665172726785	\N	131070	Spenden	\N	\N	\N	2025-02-27 02:29:57.829	\N	\N
1454852184427463802	1454850282016998511	1454850890090415217	1452651665172726785	\N	196605	Nebenkostenabrechnung	\N	\N	\N	2025-02-27 02:31:35.304	\N	\N
1454853585257890945	1454850282016998511	1454853343691146368	1452651665172726785	\N	65535	Tag zu Hause / im Homeoffice	\N	\N	\N	2025-02-27 02:34:22.296	\N	\N
1454853686458057859	1454850282016998511	1454853271012246655	1452651665172726785	\N	65535	Ehrenamt	\N	\N	\N	2025-02-27 02:34:34.36	\N	\N
1454854485540078725	1454850282016998511	1454853343691146368	1452651665172726785	\N	131070	Betrag für Steuer	\N	\N	\N	2025-02-27 02:36:09.618	\N	\N
1698808620453463709	1698777948523333106	1698808525116933786	1452651665172726785	\N	131070	Zählerstände (Strom, Gas, Wasser) mit Fotos	\N	\N	\N	2026-01-29 16:49:28.726	\N	\N
1698808660458735263	1698777948523333106	1698808525116933786	1452651665172726785	\N	196605	Schlüsselanzahl übergeben	\N	\N	\N	2026-01-29 16:49:33.494	\N	\N
1698808715202791073	1698777948523333106	1698808525116933786	1452651665172726785	\N	262140	Zustand der Wohnung (Wände, Böden, Fenster, Sanitär) — Mängel fotografisch festhalten	\N	\N	\N	2026-01-29 16:49:40.021	\N	\N
1698808754755077795	1698777948523333106	1698808525116933786	1452651665172726785	\N	327675	Unterschriften: Mieter & Vermieter	\N	\N	\N	2026-01-29 16:49:44.736	\N	\N
1467269901491111072	1467269675300684956	1467269769538307230	1452651665172726785	\N	65535	Rollen	**Super Admin**\n* Darf alles sehen und bearbeiten.\n\n**Manager** (öffentliche Registrierung)\n* wird man nachdem man sich registriert hat\n* Darf neue Teams anlegen und verwalten\n* Darf einen **Team Admin** einladen (spezieller/privater Registrierungs-Link)\n* Darf das gleiche wie ein **Team Admin**\n\n**Team Admin**\n* Darf neue Spieler anlegen und verwalten\n* Darf neue Kassen anlegen und verwalten\n* Darf einen **Kassen User** einladen (spezieller/privater Registrierungs-Link)\n* Darf das gleiche wie ein **Kassen User**\n\n**Kassen User**\n* Wird von einem Team Admin angelegt\n* Darf eine bestimmte Kasse verwalten	\N	\N	2025-03-16 05:43:22.533	2025-03-16 05:56:38.102	\N
1452867535991997489	1452867106646262825	1452867359294358574	1452651665172726785	\N	16383.75	Mein TSV Rechnungen erstellt	\N	\N	\N	2025-02-24 08:48:26.776	2026-01-29 17:21:36.302	\N
1701049702268536637	1688436604735063529	1701049333362722616	1452651665172726785	\N	98302.5	Panel	\N	\N	\N	2026-02-01 19:02:06.495	2026-02-01 19:03:50.799	\N
1493636127771329711	1493635838540514476	1493635969671234734	1452651665172726785	\N	65535	Maestro Cams auf Chalét	\N	\N	\N	2025-04-21 14:48:21.636	\N	\N
1493636512707773617	1493635838540514476	1493643906317812915	1452651665172726785	\N	65535	Lesion Black Ice Tarnung	\N	\N	\N	2025-04-21 14:49:07.524	2025-04-21 15:03:50.868	\N
1495906931447956675	1495094452761396405	1545934746901546214	1452651665172726785	\N	131070	Rundlaufbahn Reinigung	\N	\N	\N	2025-04-24 18:00:02.529	2025-07-02 18:36:38.8	\N
1495905269958313153	1495905149799892158	1495905200894903488	1452651665172726785	\N	65535	Metalldetektor	\N	\N	\N	2025-04-24 17:56:44.466	\N	\N
1545189491239552210	1545189208367301839	1545189262247331025	1452651665172726785	\N	65535	Verbrauch vom Dünger prognostizieren	bsp\npro Durchgang:\nTerra Flores 100ml\n\n40 Tage verbleibend / alle 4 Tage gießen = weitere 10 Durchgänge a 100ml = 1000ml	\N	\N	2025-07-01 17:55:41.468	2025-07-01 17:58:14.914	\N
1488928634856015016	1452662097665065992	1452662456613602316	1452651665172726785	\N	32767.5	Video online stellen	\N	\N	\N	2025-04-15 02:55:24.75	2025-07-01 18:50:50.959	\N
1452865885491430430	1452662097665065992	1452662456613602316	1452651665172726785	\N	16383.75	Klamotten bei Hellbusch besorgen	\N	\N	\N	2025-02-24 08:45:10.018	2025-07-01 18:50:52.129	\N
1452865745032578076	1452662097665065992	1452662456613602316	1452651665172726785	\N	8191.875	Werbung für Tauziehen auf HP machen	\N	\N	\N	2025-02-24 08:44:53.269	2025-07-01 18:50:54.057	\N
1452866225674650660	1452662097665065992	1452662456613602316	1452651665172726785	\N	4095.9375	Kuchen für Sonntag backen	\N	\N	\N	2025-02-24 08:45:50.572	2025-07-01 18:50:57.178	\N
1545217220420830420	1452662097665065992	1452662319485027338	1452651665172726785	\N	458745	Logo erstellen	ein Logo welches den Marktausschuss representieren soll	\N	\N	2025-07-01 18:50:47.044	2025-07-01 18:51:48.896	\N
1495094604737807544	1495094452761396405	1545934746901546214	1452651665172726785	\N	32767.5	Michael Kirmes von HP entfernen	Badminton Abteilung	2025-04-30 10:00:00	\N	2025-04-23 15:06:05.639	2025-07-02 19:36:39.763	f
1545217353623536858	1452662097665065992	1452662456613602316	1452651665172726785	\N	2047.96875	Instagram Account erstellen	**Name:** marktausschuss-grossenkneten	\N	\N	2025-07-01 18:51:02.926	2025-07-01 20:46:55.285	\N
1545217939626525916	1452662097665065992	1452662456613602316	1452651665172726785	\N	1023.984375	Facebook Organisation erstellen	\N	\N	\N	2025-07-01 18:52:12.781	2025-07-01 20:46:56.902	\N
1495903843366470844	1495094452761396405	1545934746901546214	1452651665172726785	\N	65535	Ehrenamt überrascht am 15. Mai um 16 Uhr im VH	\N	\N	\N	2025-04-24 17:53:54.399	2025-07-02 18:36:34.212	\N
1563548982041380084	1563548678239552753	1563548876982453491	1452651665172726785	\N	65535	Dracheninseln	\N	\N	\N	2025-07-27 01:52:43.324	\N	\N
1564161071470609656	1563548678239552753	1563548876982453491	1452651665172726785	\N	131070	Ödland	\N	\N	\N	2025-07-27 22:08:50.039	\N	\N
1545965341757146346	1452663050141172754	1452663143976141846	1452651665172726785	\N	65535	Jannek Hülsmann	\N	\N	\N	2025-07-02 19:37:10.058	2025-09-01 17:15:25.589	\N
1495887336741799098	1452663050141172754	1452663143976141846	1452651665172726785	\N	32767.5	Mitgliederversammlung 26.6 in Teams anlegen	\N	\N	\N	2025-04-24 17:21:06.658	2025-09-01 17:15:29.779	\N
1590114143027856644	1495094452761396405	1495907783302710469	1452651665172726785	\N	196605	Vorstands Bilder	\N	\N	\N	2025-09-01 17:32:57.292	\N	\N
1545931664247489762	1495094452761396405	1495907783302710469	1452651665172726785	\N	98302.5	Sport Angebote aktualisieren / prüfen	\N	2025-09-30 10:00:00	\N	2025-07-02 18:30:15.387	2025-09-01 17:37:01.972	f
1590126459702215985	1495094452761396405	1495907783302710469	1452651665172726785	\N	458745	Vereinsinfo	Info an Mathias	\N	\N	2025-09-01 17:57:25.555	2025-09-01 17:57:57.507	\N
1590120287414781204	1495094452761396405	1545934746901546214	1452651665172726785	\N	16383.75	Contao Zugang anlegen	\N	\N	\N	2025-09-01 17:45:09.759	2025-09-07 15:05:44.577	\N
1590158123518133569	1452663050141172754	1452663077236376596	1452651665172726785	\N	131070	Vereinsheim Buchung organisieren	\N	\N	\N	2025-09-01 19:00:20.175	\N	\N
1590115842752775436	1495094452761396405	1545934746901546214	1452651665172726785	\N	8191.875	Das ist der TSV - Tarik Info hinzufügen	\N	\N	\N	2025-09-01 17:36:19.915	2025-09-07 15:13:32.442	\N
1590105516418270462	1495094452761396405	1545934746901546214	1452651665172726785	\N	4095.9375	Spendenlink BFD teilen	\N	\N	\N	2025-09-01 17:15:48.921	2025-09-07 15:14:17.425	\N
1590138671737079097	1452663196799206423	1452663850364044315	1452651665172726785	\N	65535	Leichtathletik Accounts	\N	\N	\N	2025-09-01 18:21:41.343	2025-09-07 14:55:48.267	\N
1612741998945502546	1612741356319409482	1612741563408975180	1452651665172726785	\N	131070	Übersicht alle Bewerbungen die eine Mail erhalten halten	\N	\N	\N	2025-10-02 22:50:27.92	\N	\N
1467099078939640975	1452867106646262825	1452867359294358574	1452651665172726785	\N	131070	Wüstenrot Bausparvertrag kündigen	\N	\N	\N	2025-03-16 00:03:58.898	2025-10-06 02:39:20.599	\N
1452868246398043201	1452867106646262825	1452867359294358574	1452651665172726785	\N	196605	Zahnzusatzversicherung tecis Feedback geben	\N	\N	\N	2025-02-24 08:49:51.461	2025-10-06 02:39:20.605	\N
1612743096787797343	1612741356319409482	1612741563408975180	1452651665172726785	\N	327675	Skills Tabelle	\N	\N	\N	2025-10-02 22:52:38.792	\N	\N
1498245717855044807	1452867106646262825	1452867359294358574	1452651665172726785	\N	57343.125	ebase Sparen pausieren	\N	\N	\N	2025-04-27 23:26:47.595	2025-10-06 02:39:20.612	\N
1467100003523626130	1452867106646262825	1452867359294358574	1452651665172726785	\N	49151.25	Dauerafträge prüfen/kündigen	\N	\N	\N	2025-03-16 00:05:49.117	2025-10-06 02:39:20.616	\N
1452867715172664371	1452867106646262825	1452867359294358574	1452651665172726785	\N	73726.875	Lebenslauf erweitern	\N	\N	\N	2025-02-24 08:48:48.134	2025-10-06 02:39:20.62	\N
1551736327160988910	1452867106646262825	1452867359294358574	1452651665172726785	\N	65535	FNZ aussetzen	\N	\N	\N	2025-07-10 18:43:05.123	2025-10-06 02:39:20.621	\N
1452867478580364335	1452867106646262825	1452867359294358574	1452651665172726785	\N	81918.75	Mein TSV deployen	\N	\N	\N	2025-02-24 08:48:19.931	2025-10-06 02:39:20.627	\N
1452868021348467773	1452867106646262825	1452867359294358574	1452651665172726785	\N	114686.25	Terasse aufäumen	\N	\N	\N	2025-02-24 08:49:24.635	2025-10-06 02:39:20.629	\N
1612746521000805749	1612741356319409482	1612741563408975180	1452651665172726785	\N	655350	README.md	\N	\N	\N	2025-10-02 22:59:26.991	\N	\N
1452867801080398901	1452867106646262825	1452867359294358574	1452651665172726785	\N	122878.125	Torsten Vogel kontaktieren	\N	\N	\N	2025-02-24 08:48:58.375	2025-10-06 02:39:20.63	\N
1612742277539562838	1612741356319409482	1612741563408975180	1452651665172726785	\N	98302.5	Stellenbeschreibung	\N	\N	\N	2025-10-02 22:51:01.13	2025-10-02 23:34:23.007	\N
1612742949911659868	1612741356319409482	1612741563408975180	1452651665172726785	\N	114686.25	Dokumente	\N	\N	\N	2025-10-02 22:52:21.284	2025-10-02 23:34:24.027	\N
1612744486931137896	1612741356319409482	1612741563408975180	1452651665172726785	\N	122878.125	Wizard	\N	\N	\N	2025-10-02 22:55:24.511	2025-10-02 23:34:25.713	\N
1454802921228076136	1452867106646262825	1452867359294358574	1452651665172726785	\N	98302.5	Steuererklärung machen	\N	\N	\N	2025-02-27 00:53:42.672	2025-10-06 02:39:20.632	\N
1612743494147769698	1612741356319409482	1612741563408975180	1452651665172726785	\N	229372.5	Termin Formular	\N	\N	\N	2025-10-02 22:53:26.162	2025-10-02 23:34:28.708	\N
1612755115070981500	1612741356319409482	1612741563408975180	1452651665172726785	\N	278523.75	Übersetzungen	\N	\N	\N	2025-10-02 23:16:31.431	2025-10-02 23:34:30.083	\N
1612744929782531436	1612741356319409482	1612741563408975180	1452651665172726785	\N	720885	Ideen	\N	\N	\N	2025-10-02 22:56:17.303	2025-10-02 23:34:31.247	\N
1615056370392892844	1467269675300684956	1467269769538307230	1452651665172726785	\N	196605	Öffentlicher Link mit temporärer Laufzeit für Spieler, die ihre Bilanz sehen wollen oder für eine ganze Mannschaft	\N	\N	\N	2025-10-06 03:28:42.495	\N	\N
1615057444327654830	1467269675300684956	1467269769538307230	1452651665172726785	\N	262140	migration der alten daten	\N	\N	\N	2025-10-06 03:30:50.519	\N	\N
1612764446684349839	1612741356319409482	1612741563408975180	1452651665172726785	\N	129022.03125	Jobs	\N	\N	\N	2025-10-02 23:35:03.899	2025-10-02 23:38:46.144	\N
1612765690983351703	1612741356319409482	1612741563408975180	1452651665172726785	\N	303099.375	Benutzer	\N	\N	\N	2025-10-02 23:37:32.233	2025-10-02 23:38:49.231	\N
1612741746901386574	1612741356319409482	1612741563408975180	1452651665172726785	\N	65535	E-Mails	\N	\N	\N	2025-10-02 22:49:57.875	2025-10-02 23:48:28.307	\N
1615057862399100336	1467269675300684956	1467269769538307230	1452651665172726785	\N	327675	spieler Bilanz, History pagination	\N	\N	\N	2025-10-06 03:31:40.356	\N	\N
1612745255789004144	1612741356319409482	1612741563408975180	1452651665172726785	\N	32767.5	Einstellungs-Wizard	Wenn ein neuer Benutzer sich anmeldet, muss dieser seine imap und smtp einstellungen setzen, da ansonsten keine mails im namen des users versendet werden können	\N	\N	2025-10-02 22:56:56.166	2025-10-03 11:58:27.194	\N
1612786389437384096	1612741356319409482	1612741563408975180	1452651665172726785	\N	130046.015625	OpenAI	\N	\N	\N	2025-10-03 00:18:39.678	2025-10-03 18:29:55.586	\N
1615058007396189618	1467269675300684956	1467269769538307230	1452651665172726785	\N	393210	Spieler zurücksetzen, Button	\N	\N	\N	2025-10-06 03:31:57.642	\N	\N
1615058060512855476	1467269675300684956	1467269769538307230	1452651665172726785	\N	458745	Mannschaft zurücksetzen, Button	\N	\N	\N	2025-10-06 03:32:03.976	\N	\N
1615058513069868470	1467269675300684956	1467269769538307230	1452651665172726785	\N	524280	Saisons einführen beziehungsweise Zeiträume für ein so genanntes Archiv	\N	\N	\N	2025-10-06 03:32:57.922	\N	\N
1615502213398922681	1452663196799206423	1452663766914171929	1452651665172726785	\N	65535	Bandenwerbung	\N	\N	\N	2025-10-06 18:14:31.124	2025-10-06 18:24:23.329	\N
1615507412146456001	1495094452761396405	1495907783302710469	1452651665172726785	\N	524280	Bandenwerbung Widget/Infos	\N	\N	\N	2025-10-06 18:24:50.863	\N	\N
1615517461514290627	1452663196799206423	1452663766914171929	1452651665172726785	\N	131070	Kosten für die Erstellung der Bandenwerbung erfragen	\N	\N	\N	2025-10-06 18:44:48.841	\N	\N
1615543573019624901	1495094452761396405	1495907783302710469	1452651665172726785	\N	589815	Katrin zur HP hinzufügen für Content Pflege	\N	\N	\N	2025-10-06 19:36:41.574	\N	\N
1626065616492299729	1626063126602450378	1626063161415173580	1452651665172726785	\N	131070	Kunden	\N	\N	\N	2025-10-21 08:02:06.903	\N	\N
1626110453551728087	1626063126602450378	1626063161415173580	1452651665172726785	\N	262140	Bandenwerbung	\N	\N	\N	2025-10-21 09:31:11.896	\N	\N
1627324853893727711	1626063126602450378	1626063161415173580	1452651665172726785	\N	458745	EMail	\N	\N	\N	2025-10-23 01:43:59.697	\N	\N
1639417119122654691	1626063126602450378	1626063161415173580	1452651665172726785	\N	524280	Logo hinzufügen und konfigurieren	\N	\N	\N	2025-11-08 18:09:10.045	\N	\N
1639417271812097509	1626063126602450378	1626063201621771725	1452651665172726785	\N	65535	Suche bei App Ansicht entfernen	\N	\N	\N	2025-11-08 18:09:28.247	2025-11-08 18:52:33.691	\N
1688437641533457902	1688436604735063529	1701033058792113974	1452651665172726785	\N	32767.5	Gemeinde muss noch die Tafel genehmigen	\N	\N	\N	2026-01-15 09:24:11.695	2026-04-06 21:02:30.313	\N
1698803786149004797	1698777948523333106	1698778097521788404	1452651665172726785	\N	327675	Urlaubstag / Helfer planen	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:52.432	2026-01-29 16:56:46.959	f
1698803930944767491	1698777948523333106	1698778097521788404	1452651665172726785	\N	524280	Große aussortier-Aktion: Kleidung, Möbel, Elektronik, Papiere (Spenden, Verkaufen, Entsorgen)	\N	2026-02-01 11:00:00	\N	2026-01-29 16:40:09.693	2026-01-29 16:57:00.698	f
1698803976234862085	1698777948523333106	1698778097521788404	1452651665172726785	\N	589815	Messungen in der neuen Wohnung machen: Türen, Treppenhaus, Räume, Fenstermaße (für Möbel, Vorhänge)	\N	2026-02-01 11:00:00	\N	2026-01-29 16:40:15.092	2026-01-29 16:57:08.075	f
1698803887063959041	1698777948523333106	1698778097521788404	1452651665172726785	\N	458745	Zählerstände (Strom, Gas, Wasser) notieren und Übergabe mit Vermieter vereinbaren	\N	2026-02-01 11:00:00	\N	2026-01-29 16:40:04.462	2026-01-29 16:57:03.56	f
1698804090487703049	1698777948523333106	1698778097521788404	1452651665172726785	\N	720885	Versicherung prüfen: Hausratversicherung ggf. anpassen / abschließen	\N	2026-02-01 11:00:00	\N	2026-01-29 16:40:28.712	2026-01-29 16:57:16.254	f
1688436908343952876	1688436604735063529	1701033058792113974	1452651665172726785	\N	65535	Social Media Termin	wird per WhatsApp Gruppe abgestimmt	\N	\N	2026-01-15 09:22:44.289	2026-02-01 18:29:04.703	\N
1698804398542554638	1698777948523333106	1698804175724348939	1452651665172726785	\N	131070	Möbel, die nicht mitkommen, verkaufen / verschenken / entsorgen	\N	2026-02-08 11:00:00	\N	2026-01-29 16:41:05.433	2026-01-29 16:56:02.814	f
1698804438707209744	1698777948523333106	1698804175724348939	1452651665172726785	\N	196605	Einrichtungsliste / Inventar erstellen (was wird mit, was neu gekauft)	\N	2026-02-08 11:00:00	\N	2026-01-29 16:41:10.223	2026-01-29 16:56:05.635	f
1698804482881619474	1698777948523333106	1698804175724348939	1452651665172726785	\N	262140	Parkplatz und Halteverbotszone prüfen / ggf. Halteverbot beantragen für Umzugstag	\N	2026-02-08 11:00:00	\N	2026-01-29 16:41:15.488	2026-01-29 16:56:09.546	f
1698803585703216629	1698777948523333106	1698778097521788404	1452651665172726785	\N	65535	Mietvertrag der neuen Wohnung prüfen (Einzugstermin, Schlüsselübergabe, Renovierungsvereinbarungen)	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:28.535	2026-01-29 16:56:30.85	f
1698804608232588820	1698777948523333106	1698804175724348939	1452651665172726785	\N	327675	Nachsendeauftrag bei der Post online einrichten (Nachsendezeitraum wählen)	\N	2026-02-07 11:00:00	\N	2026-01-29 16:41:30.429	2026-01-29 16:51:19.755	f
1698804245995718156	1698777948523333106	1698804175724348939	1452651665172726785	\N	65535	Unnötige/saisonale Dinge packen (Deko, Bücher, selten genutzte Küchengeräte)	\N	2026-02-08 11:00:00	\N	2026-01-29 16:40:47.25	2026-01-29 16:56:00.134	f
1698805722600441398	1698777948523333106	1698805297876829739	1452651665172726785	\N	393210	Schlüssel für neue Wohnung abholen oder Übergabe bestätigen	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:43.273	2026-01-29 16:55:11.938	f
1698803742360471035	1698777948523333106	1698778097521788404	1452651665172726785	\N	262140	Angebote von Umzugsfirmen einholen / Transporter reservieren	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:47.211	2026-01-29 16:56:43.189	f
1688442986603480560	1688436604735063529	1701033058792113974	1452651665172726785	\N	16383.75	Ende Januar Prototypen	\N	\N	\N	2026-01-15 09:34:48.876	2026-04-06 21:02:31.957	\N
1698804821034796571	1698777948523333106	1698804761484068378	1452651665172726785	\N	65535	Verträge ummelden oder kündigen: Strom, Gas, Wasser, Internet/TV, Telefon, Abonnements	\N	2026-02-14 11:00:00	\N	2026-01-29 16:41:55.8	2026-01-29 16:51:33.442	f
1698805166947436073	1698777948523333106	1698804761484068378	1452651665172726785	\N	524280	Pflege-/Medikamentenvorrat prüfen	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:37.036	2026-01-29 16:55:53.09	f
1698804657809262102	1698777948523333106	1698804175724348939	1452651665172726785	\N	393210	Erste Ummeldungen planen (Arbeitgeber, Bank, Versicherung, Steuerberater, Kfz-Zulassung falls relevant)	\N	2026-02-08 11:00:00	\N	2026-01-29 16:41:36.341	2026-01-29 16:56:12.325	f
1698804710196119064	1698777948523333106	1698804175724348939	1452651665172726785	\N	458745	Angebote für Renovierungs-/Reinigungsfirmen (falls Endreinigung kostenpflichtig) einholen	\N	2026-02-08 11:00:00	\N	2026-01-29 16:41:42.587	2026-01-29 16:56:15.509	f
1698805610427975220	1698777948523333106	1698805297876829739	1452651665172726785	\N	327675	Zählerstände am Ab- und Einzugstag notieren und fotografieren	\N	2026-02-21 11:00:00	\N	2026-01-29 16:43:29.901	2026-01-29 16:52:34.168	f
1698805472770917934	1698777948523333106	1698805297876829739	1452651665172726785	\N	131070	Wichtige Möbel auseinanderbauen (Bett, Regale) und Schrauben in klar gekennzeichneten Tütchen befestigen	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:13.493	2026-01-29 16:55:02.136	f
1698805518203618864	1698777948523333106	1698805297876829739	1452651665172726785	\N	196605	Möbel und Böden schützen: Filzgleiter, Decken, Kartons	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:18.909	2026-01-29 16:55:05.393	f
1698805559844668978	1698777948523333106	1698805297876829739	1452651665172726785	\N	262140	Abschluss-/Übergabeprotokoll für alte Wohnung vorbereiten (Fotos planen)	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:23.873	2026-01-29 16:55:08.158	f
1698805428420347436	1698777948523333106	1698805297876829739	1452651665172726785	\N	65535	Restliche Sachen packen; nur noch tägliche Kleidung & Toilettenartikel offen lassen	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:08.206	2026-01-29 16:55:22.504	f
1698804863992858141	1698777948523333106	1698804761484068378	1452651665172726785	\N	131070	Internet/TV/Telefon Anschluss an neuem Wohnort beantragen oder Umzugstermin vereinbaren	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:00.921	2026-01-29 16:55:29.998	f
1698804913359816223	1698777948523333106	1698804761484068378	1452651665172726785	\N	196605	Schlüsselsituation klären: Ersatzschlüssel bestellen, Schlüsselübergabe planen	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:06.806	2026-01-29 16:55:32.544	f
1698804968917567009	1698777948523333106	1698804761484068378	1452651665172726785	\N	262140	Wertvolle Dokumente & Wertsachen separat sichern (in Ordner/Mappe, Transport persönlich)	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:13.429	2026-01-29 16:55:35.207	f
1698805012680934947	1698777948523333106	1698804761484068378	1452651665172726785	\N	327675	Kühlschrank/ Gefrierschrank langsam leeren; verderbliche Lebensmittel aufbrauchen / spenden	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:18.646	2026-01-29 16:55:41.115	f
1698805065705326117	1698777948523333106	1698804761484068378	1452651665172726785	\N	393210	Pack-Plan für jeden Raum erstellen (Farbcodes / Nummern für Kartons)	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:24.966	2026-01-29 16:55:46.742	f
1698805120046728743	1698777948523333106	1698804761484068378	1452651665172726785	\N	458745	Umzugskartons beschriften: Raum + Inhalt + Priorität (z. B. "Küche — Töpfe — hoch")	\N	2026-02-15 11:00:00	\N	2026-01-29 16:42:31.445	2026-01-29 16:55:49.865	f
1698808035926869638	1698777948523333106	1698806181969004097	1452651665172726785	\N	65535	Personalausweis / Reisepass, Mietvertrag, Übergabeprotokolle	\N	\N	\N	2026-01-29 16:48:19.045	\N	\N
1698808084152977032	1698777948523333106	1698806181969004097	1452651665172726785	\N	131070	Geld, EC-/Kreditkarten	\N	\N	\N	2026-01-29 16:48:24.794	\N	\N
1698808130676197002	1698777948523333106	1698806181969004097	1452651665172726785	\N	196605	Handy + Ladegerät / Powerbank	\N	\N	\N	2026-01-29 16:48:30.34	\N	\N
1698808169465120396	1698777948523333106	1698806181969004097	1452651665172726785	\N	262140	Medikamente, Erste-Hilfe-Set	\N	\N	\N	2026-01-29 16:48:34.964	\N	\N
1698808224083347086	1698777948523333106	1698806181969004097	1452651665172726785	\N	327675	Toilettenpapier, Handseife, Handtücher	\N	\N	\N	2026-01-29 16:48:41.475	\N	\N
1698808267058185872	1698777948523333106	1698806181969004097	1452651665172726785	\N	393210	Basis-Kochutensilien: Wasserkocher, Kaffeefilter, Tassen, Besteck, Teller	\N	\N	\N	2026-01-29 16:48:46.598	\N	\N
1698808305889052306	1698777948523333106	1698806181969004097	1452651665172726785	\N	458745	Kleidung für 1–2 Tage	\N	\N	\N	2026-01-29 16:48:51.227	\N	\N
1698808349249767060	1698777948523333106	1698806181969004097	1452651665172726785	\N	524280	Taschenlampe, Multitool / Schraubenzieher, Hammer, Ersatzglühbirnen	\N	\N	\N	2026-01-29 16:48:56.396	\N	\N
1698808388793665174	1698777948523333106	1698806181969004097	1452651665172726785	\N	589815	Schlüssel (alt & neu)	\N	\N	\N	2026-01-29 16:49:01.109	\N	\N
1698808429931398808	1698777948523333106	1698806181969004097	1452651665172726785	\N	655350	Reinigungsmittel, Müllbeutel, Schwamm	\N	\N	\N	2026-01-29 16:49:06.014	\N	\N
1698805837599868474	1698777948523333106	1698805297876829739	1452651665172726785	\N	524280	Kinderbetreuung/Haustierbetreuung für Umzugstag organisieren	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:56.984	2026-01-29 16:55:18.097	f
1698803648793937399	1698777948523333106	1698778097521788404	1452651665172726785	\N	131070	Kündigungsfrist für alte Wohnung beachten & schriftliche Kündigung (falls noch nicht geschehen)	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:36.058	2026-01-29 16:56:35.641	f
1698806320515253828	1698777948523333106	1698805887235262012	1452651665172726785	\N	131070	Letzte Wäsche waschen (Bettwäsche, Handtücher)	\N	2026-02-26 11:00:00	\N	2026-01-29 16:44:54.552	2026-01-29 16:54:28.986	f
1698806370695906886	1698777948523333106	1698805887235262012	1452651665172726785	\N	196605	Kleidung für Umzugstag/erste Tage einpacken (Reise-/Essentials-Koffer)	\N	2026-02-26 11:00:00	\N	2026-01-29 16:45:00.534	2026-01-29 16:54:31.825	f
1698806415851783752	1698777948523333106	1698805887235262012	1452651665172726785	\N	262140	Umzugshelfer nochmal bestätigen (Ort, Zeit, Parken, Verpflegung)	\N	2026-02-26 11:00:00	\N	2026-01-29 16:45:05.917	2026-01-29 16:54:35.785	f
1698806454288385610	1698777948523333106	1698805887235262012	1452651665172726785	\N	327675	Medikamente/ wichtige Unterlagen zusammenstellen	\N	2026-02-26 11:00:00	\N	2026-01-29 16:45:10.499	2026-01-29 16:54:39.201	f
1698806497867204172	1698777948523333106	1698805887235262012	1452651665172726785	\N	393210	Letzte Einkäufe: Küchenrolle, Putzmittel, Müllbeutel, Toilettenpapier, Grundnahrungsmittel	\N	2026-02-26 11:00:00	\N	2026-01-29 16:45:15.694	2026-01-29 16:54:42.019	f
1698805771103372856	1698777948523333106	1698805297876829739	1452651665172726785	\N	458745	Recycling/ Sperrmülltermin für alte Wohnung planen	\N	2026-02-22 11:00:00	\N	2026-01-29 16:43:49.057	2026-01-29 16:55:14.929	f
1698806675009439316	1698777948523333106	1698805928733705789	1452651665172726785	\N	262140	Gebäude- und Wohnungsschlüssel sortieren & bereitlegen	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:36.812	2026-01-29 16:53:54.533	f
1698806541940950606	1698777948523333106	1698805928733705789	1452651665172726785	\N	65535	Notfall- / Essentials-Kiste bereitstellen (siehe weiter unten)	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:20.948	2026-01-29 16:53:49.171	f
1698806616993826386	1698777948523333106	1698805928733705789	1452651665172726785	\N	196605	Wertsachen/ Dokumente separat transportieren (z. B. in Handgepäck)	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:29.895	2026-01-29 16:53:42.111	f
1698806579983287888	1698777948523333106	1698805928733705789	1452651665172726785	\N	131070	Elektronische Geräte sichern, Kabel beschriften	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:25.483	2026-01-29 16:53:45.53	f
1698806717564847702	1698777948523333106	1698805928733705789	1452651665172726785	\N	327675	Letzte Reinigung auf alten Wohnungsflächen (wenn selbst gemacht)	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:41.884	2026-01-29 16:53:59.029	f
1698806763198875224	1698777948523333106	1698805928733705789	1452651665172726785	\N	393210	Zählerstände fotografieren (Strom, Gas, Wasser)	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:47.324	2026-01-29 16:54:02.589	f
1698806799982921306	1698777948523333106	1698805928733705789	1452651665172726785	\N	458745	Müll entsorgen, letzte Abfälle trennen	\N	2026-02-28 11:00:00	\N	2026-01-29 16:45:51.709	2026-01-29 16:54:08.301	f
1698806276533782082	1698777948523333106	1698805887235262012	1452651665172726785	\N	65535	Kühlschrank abtauen und reinigen (mind. 24–48 Std vorher ausräumen falls Gefrierfach)	\N	2026-02-26 11:00:00	\N	2026-01-29 16:44:49.307	2026-01-29 16:54:25.867	f
1698803696189572601	1698777948523333106	1698778097521788404	1452651665172726785	\N	196605	Umzugsdatum finalisieren und Mitbewohner/Freunde/Umzugsfirma reservieren	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:41.707	2026-01-29 16:56:39.849	f
1698803837227238911	1698777948523333106	1698778097521788404	1452651665172726785	\N	393210	Übergabetermin der neuen Wohnung bestätigen (Termin für Schlüsselübergabe)	\N	2026-02-01 11:00:00	\N	2026-01-29 16:39:58.521	2026-01-29 16:56:50.769	f
1698804027287930375	1698777948523333106	1698778097521788404	1452651665172726785	\N	655350	Verpackungsmaterial besorgen: Kartons (verschiedene Größen), Klebeband, Seidenpapier, Luftpolsterfolie, Marker, Packdecken	\N	2026-02-01 11:00:00	\N	2026-01-29 16:40:21.178	2026-01-29 16:57:12.111	f
1698806863266580060	1698777948523333106	1698805970097931838	1452651665172726785	\N	65535	Pünktlich vor Ort sein und Helfer einweisen	\N	2026-03-01 11:00:00	\N	2026-01-29 16:45:59.252	2026-01-29 16:57:27.531	f
1698806901376026206	1698777948523333106	1698805970097931838	1452651665172726785	\N	131070	Schweres zuerst: Möbel, große Geräte; Kartons dann gestapelt	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:03.795	2026-01-29 16:57:31.684	f
1698807025351263840	1698777948523333106	1698805970097931838	1452651665172726785	\N	196605	Übergabeprotokoll alte Wohnung mit Vermieter machen (Fotos, Mängel protokollieren)	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:18.573	2026-01-29 16:57:35.602	f
1698807073577371234	1698777948523333106	1698805970097931838	1452651665172726785	\N	262140	Zählerstände in neuer Wohnung fotografieren	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:24.324	2026-01-29 16:57:41.593	f
1698807156658144870	1698777948523333106	1698805970097931838	1452651665172726785	\N	393210	Schlüsselübergabe abgeschlossen? Unterschriften sichern	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:34.228	2026-01-29 16:57:56.824	f
1698807203307193960	1698777948523333106	1698805970097931838	1452651665172726785	\N	458745	Verpflegung/Trinkpausen für Helfer einplanen	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:39.789	2026-01-29 16:58:01.242	f
1698807251592021610	1698777948523333106	1698806018860910143	1452651665172726785	\N	65535	Elektrik, Heizung, Wasser kontrollieren	\N	2026-03-03 11:00:00	\N	2026-01-29 16:46:45.545	2026-01-29 16:58:19.103	f
1698807301596513900	1698777948523333106	1698806018860910143	1452651665172726785	\N	131070	Internet/Telefonanschluss prüfen	\N	2026-03-03 11:00:00	\N	2026-01-29 16:46:51.506	2026-01-29 16:58:23.861	f
1698807350493709934	1698777948523333106	1698806018860910143	1452651665172726785	\N	196605	Postempfang prüfen (Nachsendeauftrag aktiv?)	\N	2026-03-03 11:00:00	\N	2026-01-29 16:46:57.334	2026-01-29 16:58:32.092	f
1698807446375499378	1698777948523333106	1698806018860910143	1452651665172726785	\N	327675	Müllentsorgung/ Wertstofftrennung für neuen Wohnort merken (Abfuhrzeiten)	\N	2026-03-03 11:00:00	\N	2026-01-29 16:47:08.765	2026-01-29 16:58:37.056	f
1698807491422324340	1698777948523333106	1698806018860910143	1452651665172726785	\N	393210	Offene Kartons systematisch auspacken (Priorität: Küche, Bad, Schlafzimmer)	\N	2026-03-03 11:00:00	\N	2026-01-29 16:47:14.135	2026-01-29 16:58:39.534	f
1698807536762750582	1698777948523333106	1698806018860910143	1452651665172726785	\N	458745	Anmeldung beim Einwohnermeldeamt (Ummeldung innerhalb gesetzlicher Frist)	\N	2026-03-03 11:00:00	\N	2026-01-29 16:47:19.54	2026-01-29 16:58:41.728	f
1698807612755150456	1698777948523333106	1698806018860910143	1452651665172726785	\N	524280	Hausratversicherung abgeschlossen/angepasst? prüfen	\N	2026-03-03 11:00:00	\N	2026-01-29 16:47:28.599	2026-01-29 16:58:44.593	f
1698807767105537660	1698777948523333106	1698806081490257472	1452651665172726785	\N	131070	Einwohnermeldeamt / Kfz / Rundfunkbeitrag (GEZ) / Wahlbenachrichtigung	\N	2026-03-15 11:00:00	\N	2026-01-29 16:47:46.997	2026-01-29 16:59:04.659	f
1698807820020876926	1698777948523333106	1698806081490257472	1452651665172726785	\N	196605	Nachsendezeit prüfen / wichtige Abos anpassen	\N	2026-03-15 11:00:00	\N	2026-01-29 16:47:53.307	2026-01-29 16:59:08.725	f
1698807873154320000	1698777948523333106	1698806081490257472	1452651665172726785	\N	360442.5	Nacharbeiten an Renovierung/kleinen Reparaturen erledigen	\N	2026-03-15 11:00:00	\N	2026-01-29 16:47:59.64	2026-01-29 17:00:50.487	f
1698807910374573698	1698777948523333106	1698806081490257472	1452651665172726785	\N	327675	Restliche Kartons auspacken und entsorgen	\N	2026-03-15 11:00:00	\N	2026-01-29 16:48:04.078	2026-01-29 16:59:16.644	f
1698807971561080452	1698777948523333106	1698806081490257472	1452651665172726785	\N	393210	Nachbarschaften kennenlernen (Hausverwaltung, Nachbarn, Müllplätze)	\N	2026-03-15 11:00:00	\N	2026-01-29 16:48:11.372	2026-01-29 16:59:19.012	f
1701049384088635193	1688436604735063529	1701049333362722616	1452651665172726785	\N	65535	Location	\N	\N	\N	2026-02-01 19:01:28.566	\N	\N
1698807117676283492	1698777948523333106	1698805970097931838	1452651665172726785	\N	327675	Möbel nach Plan aufstellen & wichtige Kartons zuerst öffnen	\N	2026-03-01 11:00:00	\N	2026-01-29 16:46:29.581	2026-01-29 16:57:49.384	f
1698807397679629936	1698777948523333106	1698806018860910143	1452651665172726785	\N	262140	Erste Einkäufe erledigen (Lebensmittel, Haushaltsartikel)	\N	2026-03-03 11:00:00	\N	2026-01-29 16:47:02.96	2026-01-29 16:58:34.548	f
1698807672599479930	1698777948523333106	1698806081490257472	1452651665172726785	\N	65535	Adresse offiziell ummelden: Bank, Arbeitgeber, Steuer, Versicherungen, Krankenkasse, Kfz-Zulassung (falls nötig)	\N	2026-03-15 11:00:00	\N	2026-01-29 16:47:35.733	2026-01-29 16:59:01.314	f
1698814924425266874	1698777948523333106	1698814380986074791	1452651665172726785	\N	655350	Essentials- / Notfallbox (unbedingt persönlich transportieren)	\N	\N	\N	2026-01-29 17:02:00.218	\N	\N
1698814492411954856	1698777948523333106	1698814380986074791	1452651665172726785	\N	65535	4 Wochen vor dem Umzug	\N	2026-02-01 11:00:00	\N	2026-01-29 17:01:08.716	2026-01-29 17:07:49.502	f
1698814535613286058	1698777948523333106	1698814380986074791	1452651665172726785	\N	131070	3 Wochen vor dem Umzug	\N	2026-02-08 11:00:00	\N	2026-01-29 17:01:13.868	2026-01-29 17:07:54.278	f
1698814577170450092	1698777948523333106	1698814380986074791	1452651665172726785	\N	196605	2 Wochen vor dem Umzug	\N	2026-02-15 11:00:00	\N	2026-01-29 17:01:18.822	2026-01-29 17:08:00.003	f
1698814616177477294	1698777948523333106	1698814380986074791	1452651665172726785	\N	262140	1 Woche vor dem Umzug	\N	2026-02-22 11:00:00	\N	2026-01-29 17:01:23.472	2026-01-29 17:08:06.083	f
1698814661870225072	1698777948523333106	1698814380986074791	1452651665172726785	\N	327675	3 Tage vor dem Umzug	\N	2026-02-26 11:00:00	\N	2026-01-29 17:01:28.919	2026-01-29 17:08:17.179	f
1698814712545806002	1698777948523333106	1698814380986074791	1452651665172726785	\N	393210	1 Tag vor dem Umzug	\N	2026-02-28 11:00:00	\N	2026-01-29 17:01:34.96	2026-01-29 17:08:23.42	f
1698814755361261236	1698777948523333106	1698814380986074791	1452651665172726785	\N	458745	Umzugstag	\N	2026-03-01 11:00:00	\N	2026-01-29 17:01:40.064	2026-01-29 17:08:28.533	f
1698814807269967542	1698777948523333106	1698814380986074791	1452651665172726785	\N	524280	1–2 Tage nach dem Umzug	\N	2026-03-03 11:00:00	\N	2026-01-29 17:01:46.251	2026-01-29 17:08:36.666	f
1698814875393853112	1698777948523333106	1698814380986074791	1452651665172726785	\N	589815	1–2 Wochen nach dem Umzug	\N	2026-03-15 11:00:00	\N	2026-01-29 17:01:54.373	2026-01-29 17:08:44.863	f
1698819411844007708	1698777948523333106	1698819234039072535	1452651665172726785	\N	196605	Umzugsfirma / Transporter: Name, Telefon, Buchungsnummer	\N	\N	\N	2026-01-29 17:10:55.159	\N	\N
1698819456060360478	1698777948523333106	1698819234039072535	1452651665172726785	\N	262140	Elektrik / Wasser / Heizungstickets: Anbieter + Kundennummer	\N	\N	\N	2026-01-29 17:11:00.43	\N	\N
1698819502617134880	1698777948523333106	1698819234039072535	1452651665172726785	\N	327675	Nachsendeauftrag: Postnummer/Bestätigung	\N	\N	\N	2026-01-29 17:11:05.98	\N	\N
1698819564441175842	1698777948523333106	1698819234039072535	1452651665172726785	\N	393210	Freunde/Helfer: Namen + Mobilnummern	\N	\N	\N	2026-01-29 17:11:13.351	\N	\N
1698819746423637797	1698777948523333106	1698819694028392228	1452651665172726785	\N	65535	Packraum für Raum (niemand mischt mehrere Räume in einem Karton)	\N	\N	\N	2026-01-29 17:11:35.045	\N	\N
1698819793332733735	1698777948523333106	1698819694028392228	1452651665172726785	\N	131070	Kartons beschriften: Raum — Inhalt — "Öffnen zuerst" (z. B. Schlafzimmer — Bettwäsche — 1)	\N	\N	\N	2026-01-29 17:11:40.637	\N	\N
1698819833941985065	1698777948523333106	1698819694028392228	1452651665172726785	\N	196605	Zerbrechliches mit Luftpolster/Seidenpapier schützen; "Fragile" kennzeichnen	\N	\N	\N	2026-01-29 17:11:45.478	\N	\N
1698819883258611499	1698777948523333106	1698819694028392228	1452651665172726785	\N	262140	Schwere Gegenstände in kleine Kartons (Bücher), leichte Gegenstände in große Kartons	\N	\N	\N	2026-01-29 17:11:51.357	\N	\N
1698819924404733741	1698777948523333106	1698819694028392228	1452651665172726785	\N	327675	Wertsachen & wichtige Dokumente immer persönlich transportieren	\N	\N	\N	2026-01-29 17:11:56.262	\N	\N
1698819992830609199	1698777948523333106	1698819694028392228	1452651665172726785	\N	393210	Schrauben + Kleinteile in Tütchen an Möbel befestigen (beschriften)	\N	\N	\N	2026-01-29 17:12:04.415	\N	\N
1698820037827102513	1698777948523333106	1698819694028392228	1452651665172726785	\N	458745	Farbcode pro Raum (z. B. blau = Küche, rot = Bad) auf Kartons & Türen	\N	\N	\N	2026-01-29 17:12:09.783	\N	\N
1698820082110564147	1698777948523333106	1698819694028392228	1452651665172726785	\N	524280	Inventarliste erstellen (kurze Liste mit Kartonnummern und Inhalt)	\N	\N	\N	2026-01-29 17:12:15.063	\N	\N
1698819321448367896	1698777948523333106	1698819234039072535	1452651665172726785	\N	65535	Vermieter alte Wohnung: Name, Telefon, E-Mail	Ehepaar Jan und Heidrun Decker\nZum Kuhberg 14c\n26197 Großenkneten\n\nJan Decker: 0172 43 44 730\nHeidrun Decker: 0178 18 65 335	\N	\N	2026-01-29 17:10:44.383	2026-01-29 17:17:02.055	\N
1698819368651065114	1698777948523333106	1698819234039072535	1452651665172726785	\N	131070	Vermieter neue Wohnung / Hausverwaltung: Name, Telefon, E-Mail	Jens Klostermann\nGrevskamp\n26197 Großenkneten\n\nTel.: 0173 21 12 194	\N	\N	2026-01-29 17:10:50.011	2026-01-29 17:18:59.442	\N
1701050821325621055	1688436604735063529	1701049333362722616	1452651665172726785	\N	114686.25	PanelField	\N	\N	\N	2026-02-01 19:04:19.896	2026-02-01 19:04:21.493	\N
1701054700285069121	1688436604735063529	1701049333362722616	1452651665172726785	\N	196605	Rental	\N	\N	\N	2026-02-01 19:12:02.305	\N	\N
1701764354224949061	1688436604735063529	1701033058792113974	1452651665172726785	\N	131070	E-Mail Postein/ausgang	\N	\N	\N	2026-02-02 18:41:59.647	2026-02-03 01:30:13.636	\N
1701764666281166663	1688436604735063529	1701033058792113974	1452651665172726785	\N	196605	Settings für bspw. max wählbare Felder	\N	\N	\N	2026-02-02 18:42:36.847	2026-02-03 01:30:16.259	\N
1701764257126811459	1688436604735063529	1701033058792113974	1452651665172726785	\N	262140	Relation Managers erstellen	\N	\N	\N	2026-02-02 18:41:48.07	2026-02-03 01:30:22.896	\N
1747658981947475839	1688436604735063529	1701033058792113974	1452651665172726785	\N	639.990234375	Inhalte aus Customer Content auch im Board im Modal anzeigen	\N	\N	\N	2026-04-07 02:26:25.611	2026-04-08 01:09:24.41	\N
1747790022632802181	1688436604735063529	1701033058792113974	1452651665172726785	\N	575.9912109375	customer content erst nach freigabe ausgeben	\N	\N	\N	2026-04-07 06:46:46.878	2026-04-08 01:09:27.311	\N
1702735470699480914	1626063126602450378	1626063201621771725	1452651665172726785	\N	131070	Dokumente können nicht hochgeladen werden	\N	\N	\N	2026-02-04 02:51:25.752	2026-02-04 06:31:27.258	\N
1702735106147354448	1626063126602450378	1626063201621771725	1452651665172726785	\N	196605	location "active" fehlt in form	kann Standorte nicht de-/aktivieren	\N	\N	2026-02-04 02:50:42.294	2026-02-04 06:31:29.257	\N
1702734949162944334	1626063126602450378	1626063201621771725	1452651665172726785	\N	262140	Felder als reserviert kennzeichnen bzw. anzahl der anfragen anzeigen	\N	\N	\N	2026-02-04 02:50:23.58	2026-02-04 06:31:32.972	\N
1702846675036407641	1626063126602450378	1626063161415173580	1452651665172726785	\N	589815	Standort in Table per Toggle de/aktivieren	\N	\N	\N	2026-02-04 06:32:22.342	\N	\N
1703443681823950683	1626063126602450378	1626063161415173580	1452651665172726785	\N	655350	Einmalige Installationskosten mit ausgeben pro Kategorie	\N	\N	\N	2026-02-05 02:18:31.094	\N	\N
1703444047265269597	1626063126602450378	1626063161415173580	1452651665172726785	\N	720885	Bilder / Videos für Page content hochladen	\N	\N	\N	2026-02-05 02:19:14.658	\N	\N
1707198061735839583	1612741356319409482	1612741563408975180	1452651665172726785	\N	786420	Export der Stellenangebote als PDF oder Excel	\N	\N	\N	2026-02-10 06:37:48.059	\N	\N
1701765700151936841	1688436604735063529	1701033058792113974	1452651665172726785	\N	8191.875	Dokumente hochladen wie bspw Lastschrift oä	\N	\N	\N	2026-02-02 18:44:40.094	2026-04-06 21:02:34.873	\N
1748312254777919369	1688436604735063529	1701033058792113974	1452651665172726785	\N	607.99072265625	Im Feld „Ihre Nachricht“ könnte der Nutzer bereits aufgefordert werden,\nden gewünschten Text für das Feld einzugeben.	\N	\N	\N	2026-04-08 00:04:21.801	2026-04-08 01:16:48.086	\N
1748311891677022087	1688436604735063529	1701033058792113974	1452651665172726785	\N	543.99169921875	Für die Ersteinrichtung (Druck) fällt einmalig eine Pauschale von 10 € an.	\N	\N	\N	2026-04-08 00:03:38.517	2026-04-08 01:32:25.786	\N
1747498088597030767	1688436604735063529	1701033058792113974	1452651665172726785	\N	163837.5	Privatperson/Unternehmen manuell einstellbar	\N	\N	\N	2026-04-06 21:06:45.63	2026-04-07 00:11:05.071	\N
1747496789931460459	1688436604735063529	1701033058792113974	1452651665172726785	\N	98302.5	Logo/Kachelbild für Unternehmen bei Anfrage direkt mit hochladen ermöglichen	\N	\N	\N	2026-04-06 21:04:10.817	2026-04-07 00:11:10.065	\N
1747496166926321509	1688436604735063529	1701033058792113974	1452651665172726785	\N	4095.9375	Dokumente bei Anfragen zur Bestätigung auswählen	\N	\N	\N	2026-04-06 21:02:56.549	2026-04-07 00:11:14.981	\N
1747496341115766631	1688436604735063529	1701033058792113974	1452651665172726785	\N	2047.96875	Maße einzelner Kacheln in Anfrage darstellen	\N	\N	\N	2026-04-06 21:03:17.314	2026-04-07 01:05:01.668	\N
1747496515582035817	1688436604735063529	1701033058792113974	1452651665172726785	\N	1023.984375	maximale Anzahl an Kacheln die ausgewählt werden dürfen festlegen 3x3	und maximal im Format 3 x 3 Feder möglich sein	\N	\N	2026-04-06 21:03:38.112	2026-04-07 01:05:04.003	\N
1747497530813319021	1688436604735063529	1701033058792113974	1452651665172726785	\N	511.9921875	Die Angaben, Größen sollten auch bei der Auswahl und Bestellung ersichtlich sein.	\N	\N	\N	2026-04-06 21:05:39.137	2026-04-07 01:13:19.324	\N
1747686178091435905	1688436604735063529	1701033058792113974	1452651665172726785	\N	3071.953125	mehre dokumente neben/mit agbs als checkbox ausgeben	\N	\N	\N	2026-04-07 03:20:27.645	2026-04-07 04:23:36.8	\N
1747599887827994484	1688436604735063529	1701033058792113974	1452651665172726785	\N	255.99609375	Anfrage Bestätigungsmail	\N	\N	\N	2026-04-07 00:29:01.043	2026-04-07 04:23:45.285	\N
1748312581614864267	1688436604735063529	1688436647122699755	1452651665172726785	\N	917490	Formular „Inhalte bearbeiten“	Eigentlich benötigen wir nur:\no\tden finalen Text, der auf die Tafel gedruckt werden soll\no\toptional die Möglichkeit, ein Bild oder eine Datei als Beispiel hochzuladen	\N	\N	2026-04-08 00:05:00.765	2026-04-08 00:05:10.437	\N
1747642684920563579	1688436604735063529	1701033058792113974	1452651665172726785	\N	767.98828125	email template in create email form übernehmen	\N	\N	\N	2026-04-07 01:54:02.855	2026-04-08 01:09:18.324	\N
1748373451057399698	1688436604735063529	1701033058792113974	1452651665172726785	\N	559.991455078125	rechnung bei kunden nach anfrage mit anhängen	\N	\N	\N	2026-04-08 02:05:56.966	2026-04-08 03:36:55.75	\N
1748460654596982677	1688436604735063529	1688436647122699755	1452651665172726785	\N	983025	Posteingang	\N	\N	\N	2026-04-08 04:59:12.44	\N	\N
1747643657353168765	1688436604735063529	1701033058792113974	1452651665172726785	\N	527.991943359375	welcome page anpassen	\N	\N	\N	2026-04-07 01:55:58.778	2026-04-08 06:45:29.465	\N
1747611483182729078	1688436604735063529	1701033058792113974	1452651665172726785	\N	383.994140625	home route einstellen und auf app leiten	\N	\N	\N	2026-04-07 00:52:03.318	2026-04-08 06:45:30.28	\N
1753404363256104866	1753403814414649243	1753404002411743133	1452651665172726785	\N	196605	Kündigen von Verträgen und Suchen von billigsten Anbietern	\N	\N	\N	2026-04-15 00:41:28.436	\N	\N
1753404194997405600	1753403814414649243	1753404002411743133	1452651665172726785	\N	131070	Verträge/Rechnungen/Bedienungsanleitungen hochladen und verwalten	\N	\N	\N	2026-04-15 00:41:08.38	2026-04-15 00:42:14.848	\N
1753406163593988007	1753405936656975780	1753405964557485990	1452651665172726785	\N	65535	Dashboard mit Schnellzugriff zu Projekten	\N	\N	\N	2026-04-15 00:45:03.053	\N	\N
1753406184037025705	1753405936656975780	1753405964557485990	1452651665172726785	\N	131070	Verwaltung von Zugängen	\N	\N	\N	2026-04-15 00:45:05.492	2026-04-15 00:45:20.383	\N
1753406413138298795	1753405936656975780	1753405964557485990	1452651665172726785	\N	196605	Linksammler	\N	\N	\N	2026-04-15 00:45:32.801	\N	\N
1753406692101457837	1753405936656975780	1753405964557485990	1452651665172726785	\N	262140	Wiki für Anleitunge etc	\N	\N	\N	2026-04-15 00:46:06.056	\N	\N
1753416782883850159	1688436604735063529	1688436647122699755	1452651665172726785	\N	1048560	Open Graph Seiten Information hinzufügen	Open graph meta generator in IT-Tools nutzen\nhttps://ogp.me/	\N	\N	2026-04-15 01:06:08.97	2026-04-15 01:06:44.362	\N
1758946277720065970	1452867106646262825	1452867259629306923	1452651665172726785	\N	1048560	Jens wegen Zahlung der Miete zum 15ten fragen	\N	\N	\N	2026-04-22 16:12:16.121	\N	\N
1813358003395495870	1753403814414649243	1753404002411743133	1452651665172726785	\N	393210	Funktion: Bei Umzug E-Mail an alle ausgewählte Versicherungen schicken mit der neuen privaten Adresse	\N	\N	\N	2026-07-06 17:58:39.283	\N	\N
1813358258828609474	1753403814414649243	1753404002411743133	1452651665172726785	\N	458745	Ein und Ausgaben verwalten	\N	\N	\N	2026-07-06 17:59:09.733	\N	\N
1813358632423655371	1753403814414649243	1753404002411743133	1452651665172726785	\N	655350	Monatliche Übersichten über Ein-/Ausgaben	\N	\N	\N	2026-07-06 17:59:54.268	\N	\N
1813358839689381838	1753403814414649243	1753404002411743133	1452651665172726785	\N	720885	Bank Transaktionen markieren/taggen für weitere Analysen	\N	\N	\N	2026-07-06 18:00:18.977	\N	\N
1813357650100881339	1753403814414649243	1813360670771513313	1452651665172726785	\N	65535	Eigene Adresse Pflegen	\N	\N	\N	2026-07-06 17:57:57.162	2026-07-06 18:04:09.745	\N
1813358351740831685	1753403814414649243	1813360670771513313	1452651665172726785	\N	131070	Import von Bankauszügen	\N	\N	\N	2026-07-06 17:59:20.807	2026-07-06 18:04:13.844	\N
1813357595616872376	1753403814414649243	1813360670771513313	1452651665172726785	\N	196605	Versicherungen pflegen	\N	\N	\N	2026-07-06 17:57:50.67	2026-07-06 18:04:18.745	\N
1753404132326115230	1753403814414649243	1813360670771513313	1452651665172726785	\N	32767.5	Strom/Wasser/Gas Tracken	\N	\N	\N	2026-04-15 00:41:00.907	2026-07-07 00:24:36.757	\N
1814196222852859886	1753403814414649243	1753404002411743133	1452651665172726785	\N	851955	Verträge und deren angehängte Dokumente per KI analysisieren und Key-Facts raussuchen lassen	\N	\N	\N	2026-07-07 21:44:02.829	\N	\N
1813362423428548581	1753403814414649243	1753404002411743133	1452651665172726785	\N	786420	Inventar verwalten	Inventar wie Fernseher, Sofa etc haben Rechnungen und oder Bedienungsanleitungen, Garantien o.ä. die zentral an einer Stelle verwalten werden sollen.	\N	\N	2026-07-06 18:07:26.191	2026-07-06 18:08:55.442	\N
1823212638931257332	1452663196799206423	1452663766914171929	1452651665172726785	\N	196605	Trainingsstunden Portal Abgabefrist hinzufügen	\N	\N	\N	2026-07-20 08:18:03.384	\N	\N
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
1590121563422721313	1590120287414781204	1590121520229778719	2025-09-01 17:47:41.874	\N
1590121654523004194	1590105516418270462	1590121280365921566	2025-09-01 17:47:52.733	\N
1590121737201124643	1545931664247489762	1590121280365921566	2025-09-01 17:48:02.59	\N
1590122155415176486	1590115842752775436	1590122089564603685	2025-09-01 17:48:52.445	\N
1590124070878315824	1590114143027856644	1590122089564603685	2025-09-01 17:52:40.784	\N
1590126497333511475	1590126459702215985	1590121280365921566	2025-09-01 17:57:30.042	\N
1590140690799527232	1590138671737079097	1590140680473150783	2025-09-01 18:25:42.035	\N
1612763244630377859	1612745255789004144	1612762934931359104	2025-10-02 23:32:40.603	\N
1612763326679352708	1612746521000805749	1612763120336373122	2025-10-02 23:32:50.386	\N
1612763354219152773	1612755115070981500	1612763046021694849	2025-10-02 23:32:53.669	\N
1612763405272221062	1612744486931137896	1612762934931359104	2025-10-02 23:32:59.754	\N
1612763442333091207	1612743494147769698	1612763046021694849	2025-10-02 23:33:04.173	\N
1612763466752329096	1612743096787797343	1612763120336373122	2025-10-02 23:33:07.084	\N
1612763494795445641	1612742949911659868	1612762934931359104	2025-10-02 23:33:10.427	\N
1612763542367241610	1612742277539562838	1612762934931359104	2025-10-02 23:33:16.098	\N
1612763577767167371	1612741998945502546	1612763046021694849	2025-10-02 23:33:20.318	\N
1612763603419530636	1612741746901386574	1612762934931359104	2025-10-02 23:33:23.376	\N
1612764268485150094	1612744929782531436	1612764260474029453	2025-10-02 23:34:42.658	\N
1612765624059037078	1612764446684349839	1612762934931359104	2025-10-02 23:37:24.253	\N
1612765733236770201	1612765690983351703	1612763046021694849	2025-10-02 23:37:37.27	\N
1612786419183388066	1612786389437384096	1612762934931359104	2025-10-03 00:18:43.227	\N
1702735589306009429	1702735470699480914	1702735581663987540	2026-02-04 02:51:39.893	\N
1813359370629547990	1813358003395495870	1813359287196452817	2026-07-06 18:01:22.272	\N
1813359580806121432	1813357650100881339	1813359571058558935	2026-07-06 18:01:47.327	\N
1813359644047837145	1813358258828609474	1813359571058558935	2026-07-06 18:01:54.866	\N
1813359751463962586	1813358351740831685	1813359571058558935	2026-07-06 18:02:07.669	\N
1813360421755684831	1813358839689381838	1813359571058558935	2026-07-06 18:03:27.576	\N
1813364600767252460	1813362423428548581	1813359571058558935	2026-07-06 18:11:45.752	\N
1814196379115849714	1814196222852859886	1814196370366531569	2026-07-07 21:44:21.459	\N
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
1454804603261420654	1452867330278163500	1452651665172726785	t	2025-02-27 00:57:03.187	\N
1753416782976124848	1753416782883850159	1452651665172726785	t	2026-04-15 01:06:08.984	\N
1758946277812340659	1758946277720065970	1452651665172726785	t	2026-04-22 16:12:16.135	\N
1813357595734312889	1813357595616872376	1452651665172726785	t	2026-07-06 17:57:50.687	\N
1813357650184767420	1813357650100881339	1452651665172726785	t	2026-07-06 17:57:57.179	\N
1813358003437438911	1813358003395495870	1452651665172726785	t	2026-07-06 17:58:39.29	\N
1813358258870552515	1813358258828609474	1452651665172726785	t	2026-07-06 17:59:09.74	\N
1813358351774386118	1813358351740831685	1452651665172726785	t	2026-07-06 17:59:20.815	\N
1813358441406662601	1813358441305999304	1452651665172726785	t	2026-07-06 17:59:31.5	\N
1813358632683702220	1813358632423655371	1452651665172726785	t	2026-07-06 17:59:54.301	\N
1813358839781656527	1813358839689381838	1452651665172726785	t	2026-07-06 18:00:18.99	\N
1813362423520823270	1813362423428548581	1452651665172726785	t	2026-07-06 18:07:26.205	\N
1814196222936745967	1814196222852859886	1452651665172726785	t	2026-07-07 21:44:02.842	\N
1823212638981588981	1823212638931257332	1452651665172726785	t	2026-07-20 08:18:03.392	\N
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, name, color, created_at, updated_at, "position") FROM stdin;
1590121280365921566	1495094452761396405	Beiträge	midnight-blue	2025-09-01 17:47:08.129	\N	65535
1590121520229778719	1495094452761396405	Zugangsdaten	berry-red	2025-09-01 17:47:36.724	\N	131070
1590122089564603685	1495094452761396405	Content	pumpkin-orange	2025-09-01 17:48:44.593	\N	196605
1590140680473150783	1452663196799206423	Zugangsdaten	berry-red	2025-09-01 18:25:40.802	\N	65535
1612762934931359104	1612741356319409482	Prio-High	berry-red	2025-10-02 23:32:03.683	\N	65535
1612763046021694849	1612741356319409482	Prio-Normal	pumpkin-orange	2025-10-02 23:32:16.927	\N	131070
1612763120336373122	1612741356319409482	Prio-Low	bright-moss	2025-10-02 23:32:25.789	2025-10-02 23:32:38.59	196605
1612764260474029453	1612741356319409482	Ideen	morning-sky	2025-10-02 23:34:41.701	\N	262140
1702735581663987540	1626063126602450378	Kritisch	berry-red	2026-02-04 02:51:38.979	\N	65535
1813359287196452817	1753403814414649243	Feature	orange-peel	2026-07-06 18:01:12.325	\N	131070
1813359571058558935	1753403814414649243	Basis-Funktion	lagoon-blue	2026-07-06 18:01:46.164	\N	196605
1814196370366531569	1753403814414649243	KI	pink-tulip	2026-07-07 21:44:20.413	\N	262140
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, "position", name, created_at, updated_at) FROM stdin;
1452662319485027338	1452662097665065992	65535	TODO	2025-02-24 02:00:43.06	\N
1452662366008247307	1452662097665065992	131070	In Bearbeitung	2025-02-24 02:00:48.608	\N
1452662456613602316	1452662097665065992	196605	Fertig	2025-02-24 02:00:59.408	\N
1452663077236376596	1452663050141172754	65535	TODO	2025-02-24 02:02:13.393	\N
1452663143976141846	1452663050141172754	196605	Fertig	2025-02-24 02:02:21.349	\N
1452663766914171929	1452663196799206423	65535	TODO	2025-02-24 02:03:35.607	\N
1452663850364044315	1452663196799206423	196605	Fertig	2025-02-24 02:03:45.558	\N
1452867259629306923	1452867106646262825	65535	TODO	2025-02-24 08:47:53.829	2025-02-24 08:48:00.06
1452867359294358574	1452867106646262825	131070	Fertig	2025-02-24 08:48:05.713	\N
1454850890090415217	1454850282016998511	65535	Ausgaben	2025-02-27 02:29:01.008	2025-02-27 02:30:58.961
1454853343691146368	1454850282016998511	196605	Arbeit	2025-02-27 02:33:53.501	\N
1454853271012246655	1454850282016998511	32767.5	Einkünfte	2025-02-27 02:33:44.836	2025-02-27 02:40:21.89
1467269769538307230	1467269675300684956	65535	ToDo	2025-03-16 05:43:06.806	\N
1467269793336788127	1467269675300684956	131070	Done	2025-03-16 05:43:09.642	\N
1493635969671234734	1493635838540514476	65535	ToDos	2025-04-21 14:48:02.79	2025-04-21 14:49:16.942
1493643906317812915	1493635838540514476	131070	Done	2025-04-21 15:03:48.911	\N
1495905200894903488	1495905149799892158	65535	Papa	2025-04-24 17:56:36.233	\N
1545189262247331025	1545189208367301839	65535	Ideen	2025-07-01 17:55:14.173	\N
1545934746901546214	1495094452761396405	196605	fertig	2025-07-02 18:36:22.869	\N
1563548876982453491	1563548678239552753	65535	Wohin?	2025-07-27 01:52:30.8	2025-07-27 22:11:37.322
1495907783302710469	1495094452761396405	131070	ToDo's	2025-04-24 18:01:44.078	2025-09-01 17:46:22.526
1590123403992368430	1590123339425252652	65535	ToDo‘s	2025-09-01 17:51:21.286	\N
1590123548813296943	1590123339425252652	131070	Abgeschlossen	2025-09-01 17:51:38.549	\N
1612741563408975180	1612741356319409482	65535	ToDos	2025-10-02 22:49:36	\N
1612741583432582477	1612741356319409482	131070	Done	2025-10-02 22:49:38.389	\N
1626063161415173580	1626063126602450378	65535	ToDos	2025-10-21 07:57:14.235	\N
1626063201621771725	1626063126602450378	131070	Erledigt	2025-10-21 07:57:19.029	\N
1688436647122699755	1688436604735063529	65535	ToDos	2026-01-15 09:22:13.154	\N
1698808525116933786	1698777948523333106	491512.5	Übergabeprotokoll — kurz (alte Wohnung)	2026-01-29 16:49:17.359	2026-01-29 16:59:32.736
1698814380986074791	1698777948523333106	32767.5	Umzug	2026-01-29 17:00:55.435	2026-01-29 17:07:40.325
1698819234039072535	1698777948523333106	557047.5	Wichtige Adressen	2026-01-29 17:10:33.961	2026-01-29 17:10:36.929
1698819694028392228	1698777948523333106	622582.5	Packtipps & Ordnungssystem	2026-01-29 17:11:28.797	2026-01-29 17:12:18.558
1701033058792113974	1688436604735063529	131070	Erledigt	2026-02-01 18:29:02.438	\N
1701049333362722616	1688436604735063529	196605	Models	2026-02-01 19:01:22.518	\N
1753405964557485990	1753405936656975780	65535	Features	2026-04-15 00:44:39.328	\N
1813360628341934048	1753403814414649243	131070	In Bearbeitung	2026-07-06 18:03:52.201	\N
1813360670771513313	1753403814414649243	196605	Erledigt	2026-07-06 18:03:57.261	\N
1753404002411743133	1753403814414649243	65535	Pipeline	2026-04-15 00:40:45.421	2026-07-06 18:04:02.214
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20180721020022_create_next_id_function.js	1	2025-02-24 01:39:32.418+00
2	20180721021044_create_archive_table.js	1	2025-02-24 01:39:32.453+00
3	20180721220409_create_user_account_table.js	1	2025-02-24 01:39:32.531+00
4	20180721233450_create_project_table.js	1	2025-02-24 01:39:32.541+00
5	20180721234154_create_project_manager_table.js	1	2025-02-24 01:39:32.554+00
6	20180722000627_create_board_table.js	1	2025-02-24 01:39:32.572+00
7	20180722001747_create_board_membership_table.js	1	2025-02-24 01:39:32.589+00
8	20180722003437_create_label_table.js	1	2025-02-24 01:39:32.599+00
9	20180722003502_create_list_table.js	1	2025-02-24 01:39:32.632+00
10	20180722003614_create_card_table.js	1	2025-02-24 01:39:32.655+00
11	20180722005122_create_card_subscription_table.js	1	2025-02-24 01:39:32.691+00
12	20180722005359_create_card_membership_table.js	1	2025-02-24 01:39:32.703+00
13	20180722005928_create_card_label_table.js	1	2025-02-24 01:39:32.719+00
14	20180722006570_create_task_table.js	1	2025-02-24 01:39:32.731+00
15	20180722006688_create_attachment_table.js	1	2025-02-24 01:39:32.754+00
16	20181024220134_create_action_table.js	1	2025-02-24 01:39:32.774+00
17	20181112104653_create_notification_table.js	1	2025-02-24 01:39:32.802+00
18	20220523131229_add_image_to_attachment_table.js	1	2025-02-24 01:39:32.806+00
19	20220713145452_add_position_to_task_table.js	1	2025-02-24 01:39:32.813+00
20	20220725150723_add_language_to_user_account_table.js	1	2025-02-24 01:39:32.814+00
21	20220729142434_add_index_on_type_to_action_table.js	1	2025-02-24 01:39:32.824+00
22	20220803221221_add_password_changed_at_to_user_account_table.js	1	2025-02-24 01:39:32.825+00
23	20220815155645_add_permissions_to_board_membership_table.js	1	2025-02-24 01:39:32.833+00
24	20220906094517_create_session_table.js	1	2025-02-24 01:39:32.859+00
25	20221003140000_@.js	1	2025-02-24 01:39:32.859+00
26	20221223131625_preserve_original_format_of_images.js	1	2025-02-24 01:39:32.864+00
27	20221225224651_remove_board_types.js.js	1	2025-02-24 01:39:32.866+00
28	20221226210239_improve_quality_of_resized_images.js	1	2025-02-24 01:39:32.868+00
29	20230108213138_labels_reordering.js	1	2025-02-24 01:39:32.874+00
30	20230227170557_rename_timer_to_stopwatch.js	1	2025-02-24 01:39:32.875+00
31	20230809022050_oidc_with_pkce_flow.js	1	2025-02-24 01:39:32.897+00
32	20240721171239_languages_with_country_codes.js	1	2025-02-24 01:39:32.898+00
33	20240812065305_make_due_date_toggleable.js	1	2025-02-24 01:39:32.9+00
34	20240831195806_additional_http_only_token_for_enhanced_security_in_browsers.js	1	2025-02-24 01:39:32.901+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, action_id, card_id, is_read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, name, background, created_at, updated_at, background_image) FROM stdin;
1452661474173387782	Marktausschuss	{"name": "green-mist", "type": "gradient"}	2025-02-24 01:59:02.291	2025-02-24 01:59:10.86	\N
1452866590914642983	Privat	{"name": "algae-green", "type": "gradient"}	2025-02-24 08:46:34.112	2025-02-24 08:49:59.679	\N
1467269614944650394	Laravel Kasse	\N	2025-03-16 05:42:48.373	\N	\N
1493635767044408490	GAMING	{"name": "tzepesch-style", "type": "gradient"}	2025-04-21 14:47:38.623	2025-04-21 14:48:36.366	\N
1452662711828612109	TSV	{"name": "coral-reef", "type": "gradient"}	2025-02-24 02:01:29.831	2025-04-24 17:56:55.788	\N
1545189120085591245	Home Assistant	\N	2025-07-01 17:54:57.208	\N	\N
1612741231933130056	dein-bewerbungshelfer.de	{"type": "image"}	2025-10-02 22:48:56.452	2025-10-02 23:53:14.469	{"dirname": "e4b3ce2e-deed-4842-af91-2d8c8df06e58", "extension": "png"}
1626062972277229000	Laravel Bandenwerbung	\N	2025-10-21 07:56:51.686	\N	\N
1753403700707067801	Projekt-Ideen	\N	2026-04-15 00:40:09.454	\N	\N
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1452661474232108039	1452661474173387782	1452651665172726785	2025-02-24 01:59:02.3	\N
1452662711920886798	1452662711828612109	1452651665172726785	2025-02-24 02:01:29.844	\N
1452866590948197416	1452866590914642983	1452651665172726785	2025-02-24 08:46:34.118	\N
1467269614986593435	1467269614944650394	1452651665172726785	2025-03-16 05:42:48.381	\N
1493635767077962923	1493635767044408490	1452651665172726785	2025-04-21 14:47:38.64	\N
1545189120219808974	1545189120085591245	1452651665172726785	2025-07-01 17:54:57.242	\N
1612741232017016137	1612741231933130056	1452651665172726785	2025-10-02 22:48:56.497	\N
1626062972386280905	1626062972277229000	1452651665172726785	2025-10-21 07:56:51.702	\N
1753403700832896922	1753403700707067801	1452651665172726785	2026-04-15 00:40:09.471	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, remote_address, user_agent, created_at, updated_at, deleted_at, http_only_token) FROM stdin;
1452657348068770821	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjA4NDY3MjFiLWY2ZjgtNGFlMi1iOGJhLWM0MWQ4ZjY5YjFmZCJ9.eyJpYXQiOjE3NDAzNjE4NTAsImV4cCI6MTc3MTg5Nzg1MCwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.omp3JrCymUk5kUGoko3iaL9Jb6r_vPlNOqgcV2p9K-A	192.168.178.11	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	2025-02-24 01:50:50.419	\N	\N	7db8f761-c554-4f81-8a86-bd823b1c2620
1465459600634414218	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRjODBhNTQwLTYzNDQtNGVmMS1hYzE2LTk2ZmQ3MzY0NjNkMiJ9.eyJpYXQiOjE3NDE4ODc5OTcsImV4cCI6MTc3MzQyMzk5Nywic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.AdDecKgdzQv6l5r2TGVXOYOLRv3W-77gmQx3UjEREZA	192.168.178.11	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36	2025-03-13 17:46:37.852	\N	\N	2c4feb04-745e-4f51-a201-a1f1dd56da31
1467098771262276747	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI0OGNlNmM0LTg0YzItNGIwMS1hZmZjLTY3ZTUwZmZlM2VhZiJ9.eyJpYXQiOjE3NDIwODM0MDIsImV4cCI6MTc3MzYxOTQwMiwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.IPC2dp8sPDInAvD1yRY1mI5MzlcGO_E7SjruVkj3Cp0	192.168.178.11	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36	2025-03-16 00:03:22.218	\N	\N	5d663d31-5ff3-482a-b20d-aed8ac98aa7c
1467645911256532132	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkwYzNmN2E0LTg3YzctNGZhOS1iMGQyLTQwZmQxMGQ4MWUyYyJ9.eyJpYXQiOjE3NDIxNDg2MjYsImV4cCI6MTc3MzY4NDYyNiwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.bw_7GEgsiMNIPyXjYoOy2sZOBbCxcgihs2DNO3PvKHg	192.168.178.111	Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3.1 Mobile/15E148 Safari/604.1	2025-03-16 18:10:26.389	\N	\N	bd11b254-300f-4889-8d33-a5aa31b5c724
1488928076577375398	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMxNGRhODFlLWQ2YjYtNGRiMC1iMDA2LWEzN2RjNTY2ZDJiOSJ9.eyJpYXQiOjE3NDQ2ODU2NTgsImV4cCI6MTc3NjIyMTY1OCwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.UAOL9cxMehY1n2k6DvhgccoPTLzRKDXqmz6tq6XIquk	192.168.178.111	Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3.1 Mobile/15E148 Safari/604.1	2025-04-15 02:54:18.187	\N	\N	0ca432d3-7070-4921-93fe-95c1fcd9b736
1563548611642393840	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjU4Y2E4YjEzLWY5MDEtNGY5OC1iZjE1LWE5MjYyNzliYWIyOCJ9.eyJpYXQiOjE3NTM1ODExMTksImV4cCI6MTc4NTExNzExOSwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.XrRXt2-6crPMYzQhyzb5FnvmGRLXltYaxywQWT0jJaA	192.168.178.11	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 01:51:59.135	\N	\N	271b9012-6255-47f8-9604-a1f5c2307e65
1682884225230964200	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ2YmRmNmVkLWYxNmItNDk0YS1iODYzLTMzMjhkY2Q4MDE1NSJ9.eyJpYXQiOjE3Njc4MDcwMzIsImV4cCI6MTc5OTM0MzAzMiwic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.TmmsgOJ1NfPFoywjr1vkyrGL5XOnGCrl3nms3m8bGb8	192.168.178.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-07 17:30:32.866	\N	\N	5a703788-af12-4c92-bd70-db993a0079cb
1823212140362729459	1452651665172726785	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNmYTQxZWYwLTVkNmUtNDczZi04NDdmLWZhNzkxZTM5MzJhYyJ9.eyJpYXQiOjE3ODQ1MzU0MjMsImV4cCI6MTgxNjA3MTQyMywic3ViIjoiMTQ1MjY1MTY2NTE3MjcyNjc4NSJ9.k6zYOcJlNnUNT9Bs6w5uQ8BCxYASG_zaULdHJP53RKQ	192.168.178.106	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Mobile/15E148 Safari/604.1	2026-07-20 08:17:03.95	\N	\N	51b02b26-adf4-4c1b-beb5-063526e020b3
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, card_id, name, is_completed, created_at, updated_at, "position") FROM stdin;
1454851277275006069	1454850979278095474	Betrag im Jahr ermitteln	f	2025-02-27 02:29:47.163	\N	65535
1454851605579957369	1454851366756287606	Johanniter-Unfall-Hilfe e. V. - 60 EUR	f	2025-02-27 02:30:26.299	2025-02-27 02:30:36.513	65535
1454853127525106814	1454851366756287606	ASB Arbeiter Samariter Bund - 60 EUR	f	2025-02-27 02:33:27.731	\N	131070
1454854725538153608	1454854485540078725	Taxfix - 39,99 EUR	f	2025-02-27 02:36:38.229	\N	65535
1467101421953352855	1467101281905542293	aktuelle Preise ermitteln	f	2025-03-16 00:08:38.209	\N	65535
1467101557639087256	1467101281905542293	EWE kündigen	f	2025-03-16 00:08:54.382	\N	131070
1467101632012485785	1467101281905542293	anderen Anbieter finden	f	2025-03-16 00:09:03.25	\N	196605
1563549415640138998	1563548982041380084	Schiff vor Orgrimmar	f	2025-07-27 01:53:35.013	2025-07-27 01:53:44.696	65535
1563549604274767095	1563548982041380084	Portal in Orgrimmar	f	2025-07-27 01:53:57.5	\N	131070
1564161757449028858	1564161071470609656	Portal von Valdrakken (26/41 links oben der Obsidian-Enklave)	f	2025-07-27 22:10:11.844	2025-07-27 22:11:06.752	65535
1590126819548333366	1590126459702215985	Info online stellen	f	2025-09-01 17:58:08.451	\N	65535
1590158279017760067	1590158123518133569	Buchungsformular	f	2025-09-01 19:00:38.712	\N	65535
1612786658829141411	1612786389437384096	Eigenes Model für das speichern von Anfragen	f	2025-10-03 00:19:11.793	\N	65535
1590138837638579516	1590138671737079097	Jonas Hinze	t	2025-09-01 18:22:01.121	2025-09-07 14:55:37.811	131070
1590138774254257467	1590138671737079097	Sebastian Engler	t	2025-09-01 18:21:53.565	2025-09-07 14:55:46.121	65535
1590120347653375254	1590120287414781204	Tim Fabian	t	2025-09-01 17:45:16.943	2025-09-07 14:57:59.637	65535
1590120381249750295	1590120287414781204	Jonas Hinze	t	2025-09-01 17:45:20.948	2025-09-07 14:59:18.219	131070
1590120480344376600	1590120287414781204	Katharina Walther	t	2025-09-01 17:45:32.76	2025-09-07 15:00:28.719	196605
1590116393599108366	1545931664247489762	Zumba entfernen	t	2025-09-01 17:37:25.581	2025-09-07 15:06:23.476	65535
1590122431408768295	1545931664247489762	Turnen mit Unterkategorien anlegen	t	2025-09-01 17:49:25.344	2025-09-07 15:10:53.31	196605
1590118235745813775	1545931664247489762	Völkerball Fotos (nur eins vorhanden?!?)	f	2025-09-01 17:41:05.18	2025-09-07 15:11:06.706	131070
1612742114825733460	1612741998945502546	als Filter	f	2025-10-02 22:50:41.736	\N	65535
1612742160585590101	1612741998945502546	als Dashboard Element	f	2025-10-02 22:50:47.19	\N	131070
1612742501481842008	1612742277539562838	als "Nur Online Möglich" markieren	f	2025-10-02 22:51:27.827	\N	65535
1612742601599878489	1612742277539562838	Filter erweitern	f	2025-10-02 22:51:39.763	2025-10-02 22:51:43.688	131070
1612742725793219930	1612742277539562838	Notizen hinzufügen	f	2025-10-02 22:51:54.567	\N	196605
1612742856697447771	1612742277539562838	Ausschreibung als PDF anhängen	f	2025-10-02 22:52:10.172	\N	262140
1612743021063832926	1612742949911659868	Vorschau erstellen	f	2025-10-02 22:52:29.767	\N	65535
1612743360215254369	1612742277539562838	Button für "Jetzt Bewerben" Seite	f	2025-10-02 22:53:10.196	\N	327675
1612743661190120804	1612743494147769698	Sekunden entfernen	f	2025-10-02 22:53:46.075	\N	65535
1612743823912338789	1612743494147769698	Endzeit mit Button (+1 Stunde usw) setzen	f	2025-10-02 22:54:05.474	\N	131070
1612744294462915942	1612743494147769698	Video Call / Telefon Call property	f	2025-10-02 22:55:01.567	\N	196605
1612744433361487207	1612743494147769698	link für Video Call (bspw. MS Teams Einladung)	f	2025-10-02 22:55:18.126	\N	262140
1612744744520123754	1612744486931137896	nach speichern nicht direkt absenden	f	2025-10-02 22:55:55.218	\N	65535
1612744842817832299	1612744486931137896	Jetzt senden oder Speichern	f	2025-10-02 22:56:06.936	\N	131070
1612744998166463854	1612744929782531436	XING Api für Job Suche	f	2025-10-02 22:56:25.457	\N	65535
1612745063371113839	1612744929782531436	LinkedIn Api	f	2025-10-02 22:56:33.23	\N	131070
1612746353446749556	1612745255789004144	laden solange Einstellungen nicht geladen sind oder benutzer möchte keine einstellungen angeben dann mail funktion für den benutzer deaktivieren	f	2025-10-02 22:59:07.017	\N	196605
1612746694099731832	1612746521000805749	Versionen anpassen	f	2025-10-02 22:59:47.628	\N	131070
1612787178083976612	1612786389437384096	Job für das Abarbeiten der Anfragen	f	2025-10-03 00:20:13.693	\N	131070
1612787435605853605	1612786389437384096	Warteschlange beim GenerierungsModal anzeigen lassen	f	2025-10-03 00:20:44.392	\N	196605
1612746659127625079	1612746521000805749	Benutzte Packages hinzufügen	f	2025-10-02 22:59:43.455	2025-10-02 23:00:03.154	65535
1612747044617717113	1612746521000805749	google-token.json Erklärung	f	2025-10-02 23:00:29.411	\N	196605
1612747128629626234	1612746521000805749	Commands auflisten	f	2025-10-02 23:00:39.429	\N	262140
1612747388970075515	1612741746901386574	has_seen für Eingehende Mails hinzufügen	f	2025-10-02 23:01:10.461	\N	196605
1612761441658471806	1612742949911659868	Dateiformate begrenzen	f	2025-10-02 23:29:05.672	\N	131070
1612761578367616383	1612742949911659868	max. Dateigröße	f	2025-10-02 23:29:21.969	\N	196605
1612764551692944785	1612764446684349839	Übersicht anpassen	f	2025-10-02 23:35:16.418	\N	65535
1615507130532496832	1615502213398922681	widget für HP	f	2025-10-06 18:24:17.292	\N	393210
1612765815059252634	1612765690983351703	Benutzer als gesperrt markieren	f	2025-10-02 23:37:47.023	\N	65535
1612745751236969842	1612745255789004144	SMTP Formular	t	2025-10-02 22:57:55.228	2025-10-03 17:26:23.96	65535
1612745838428161395	1612745255789004144	IMAP Formular	t	2025-10-02 22:58:05.623	2025-10-03 17:26:24.839	131070
1612771369290827163	1612741746901386574	Posteingang Page	t	2025-10-02 23:48:49.136	2025-10-03 18:19:10.54	32767.5
1612771417869256092	1612741746901386574	Postausgang Page	t	2025-10-02 23:48:54.931	2025-10-03 18:19:11.146	49151.25
1612771752700544415	1612741746901386574	Settings Page	t	2025-10-02 23:49:34.844	2025-10-03 18:19:30.132	122878.125
1612764674275673490	1612764446684349839	Alle Jobs löschen	t	2025-10-02 23:35:31.03	2025-10-03 20:33:24.853	131070
1612764742944818579	1612764446684349839	Alle Jobs starten	t	2025-10-02 23:35:39.218	2025-10-03 20:33:29.322	196605
1612765006162560404	1612764446684349839	Mail Import Job durchläuft alle Benutzer mit den jeweiligen IMAP Settings	t	2025-10-02 23:36:10.595	2025-10-03 23:06:47.193	262140
1612765387919721877	1612764446684349839	Mail Send Job versendet alle nicht gesendet Mails mit den jeweiligen Benutzer SMTP Settings	t	2025-10-02 23:36:56.103	2025-10-03 23:06:47.771	327675
1615502445679478203	1615502213398922681	aktuelle Infos Kosten (macht Katrin)	f	2025-10-06 18:14:58.814	\N	65535
1615502643038258620	1615502213398922681	bei fragen an info@	f	2025-10-06 18:15:22.341	\N	131070
1615502841135236541	1615502213398922681	Kosten auf netto anpassen	f	2025-10-06 18:15:45.955	\N	196605
1615503119754462654	1615502213398922681	mwst rausrechnen	f	2025-10-06 18:16:19.17	\N	262140
1615504100676339135	1615502213398922681	mama crashkurs	f	2025-10-06 18:18:16.105	\N	327675
1626063405808879056	1626063269418501582	Laufzeit zum Formular hinzufügen	f	2025-10-21 07:57:43.368	\N	65535
1626065875784173011	1626065616492299729	Filter und Tabellen Spalte für fehlender Rechnungsadresse	f	2025-10-21 08:02:37.811	\N	65535
1626070106519897558	1626069874222564820	Lageplan als PDF hochladen (dient zur Orientierung wo die Positionen liegen)	f	2025-10-21 08:11:02.155	\N	65535
1626651387678950874	1626110453551728087	den Kategorien exakte Positionen zuweisen, damit bei Auswahl der Positionen in der Inquiry oder Advertising Form	f	2025-10-22 03:25:56.269	\N	131070
1626110517196096985	1626110453551728087	Status als Enum auslagern	t	2025-10-21 09:31:19.485	2025-10-22 03:25:58.125	65535
1627324945522492897	1627324853893727711	Vorschau hinzufügen	f	2025-10-23 01:44:10.623	\N	65535
1627324965646763490	1627324853893727711	erneut senden	f	2025-10-23 01:44:13.022	\N	131070
1698815096970544828	1698814492411954856	Mietvertrag der neuen Wohnung prüfen (Einzugstermin, Schlüsselübergabe, Renovierungsvereinbarungen)	f	2026-01-29 17:02:20.785	\N	65535
1698815180504303294	1698814492411954856	Umzugsdatum finalisieren und Mitbewohner/Freunde/Umzugsfirma reservieren	f	2026-01-29 17:02:30.745	\N	196605
1698815206416713407	1698814492411954856	Angebote von Umzugsfirmen einholen / Transporter reservieren	f	2026-01-29 17:02:33.834	\N	262140
1698815236666033856	1698814492411954856	Urlaubstag / Helfer planen	f	2026-01-29 17:02:37.441	\N	327675
1698815267561277121	1698814492411954856	Übergabetermin der neuen Wohnung bestätigen (Termin für Schlüsselübergabe)	f	2026-01-29 17:02:41.123	\N	393210
1698815291208763074	1698814492411954856	Zählerstände (Strom, Gas, Wasser) notieren und Übergabe mit Vermieter vereinbaren	f	2026-01-29 17:02:43.942	\N	458745
1698815315477006019	1698814492411954856	Große aussortier-Aktion: Kleidung, Möbel, Elektronik, Papiere (Spenden, Verkaufen, Entsorgen)	f	2026-01-29 17:02:46.836	\N	524280
1698815334292653764	1698814492411954856	Messungen in der neuen Wohnung machen: Türen, Treppenhaus, Räume, Fenstermaße (für Möbel, Vorhänge)	f	2026-01-29 17:02:49.078	\N	589815
1698815380782319301	1698814492411954856	Verpackungsmaterial besorgen: Kartons (verschiedene Größen), Klebeband, Seidenpapier, Luftpolsterfolie, Marker, Packdecken	f	2026-01-29 17:02:54.621	\N	655350
1698815395680487110	1698814492411954856	Versicherung prüfen: Hausratversicherung ggf. anpassen / abschließen	f	2026-01-29 17:02:56.396	\N	720885
1698815555366028999	1698814535613286058	Unnötige/saisonale Dinge packen (Deko, Bücher, selten genutzte Küchengeräte)	f	2026-01-29 17:03:15.43	\N	65535
1698815577696503496	1698814535613286058	Möbel, die nicht mitkommen, verkaufen / verschenken / entsorgen	f	2026-01-29 17:03:18.093	\N	131070
1698815594943481545	1698814535613286058	Einrichtungsliste / Inventar erstellen (was wird mit, was neu gekauft)	f	2026-01-29 17:03:20.15	\N	196605
1698815617232013002	1698814535613286058	Parkplatz und Halteverbotszone prüfen / ggf. Halteverbot beantragen für Umzugstag	f	2026-01-29 17:03:22.807	\N	262140
1698815635368183499	1698814535613286058	Aufzugreserve beim Vermieter/ Hausverwaltung anfragen (falls nötig)	f	2026-01-29 17:03:24.969	\N	327675
1698815654838142668	1698814535613286058	Nachsendeauftrag bei der Post online einrichten (Nachsendezeitraum wählen)	f	2026-01-29 17:03:27.29	\N	393210
1698815674366822093	1698814535613286058	Erste Ummeldungen planen (Arbeitgeber, Bank, Versicherung, Steuerberater, Kfz-Zulassung falls relevant)	f	2026-01-29 17:03:29.619	\N	458745
1698815684701587150	1698814535613286058	Angebote für Renovierungs-/Reinigungsfirmen (falls Endreinigung kostenpflichtig) einholen	f	2026-01-29 17:03:30.849	\N	524280
1698815820320212687	1698814577170450092	Verträge ummelden oder kündigen: Strom, Gas, Wasser, Internet/TV, Telefon, Abonnements	f	2026-01-29 17:03:47.015	\N	65535
1698815838431217360	1698814577170450092	Internet/TV/Telefon Anschluss an neuem Wohnort beantragen oder Umzugstermin vereinbaren	f	2026-01-29 17:03:49.177	\N	131070
1698815869141911249	1698814577170450092	Schlüsselsituation klären: Ersatzschlüssel bestellen, Schlüsselübergabe planen	f	2026-01-29 17:03:52.837	\N	196605
1698815892353189586	1698814577170450092	Wertvolle Dokumente & Wertsachen separat sichern (in Ordner/Mappe, Transport persönlich)	f	2026-01-29 17:03:55.604	\N	262140
1698815909122016979	1698814577170450092	Kühlschrank/ Gefrierschrank langsam leeren; verderbliche Lebensmittel aufbrauchen / spenden	f	2026-01-29 17:03:57.602	\N	327675
1698815929481168596	1698814577170450092	Pack-Plan für jeden Raum erstellen (Farbcodes / Nummern für Kartons)	f	2026-01-29 17:04:00.03	\N	393210
1698815951325103829	1698814577170450092	Umzugskartons beschriften: Raum + Inhalt + Priorität (z. B. "Küche — Töpfe — hoch")	f	2026-01-29 17:04:02.634	\N	458745
1698815960930059990	1698814577170450092	Pflege-/Medikamentenvorrat prüfen	f	2026-01-29 17:04:03.779	\N	524280
1698816063732451031	1698814616177477294	Restliche Sachen packen; nur noch tägliche Kleidung & Toilettenartikel offen lassen	f	2026-01-29 17:04:16.034	\N	65535
1698816097202996952	1698814616177477294	Wichtige Möbel auseinanderbauen (Bett, Regale) und Schrauben in klar gekennzeichneten Tütchen befestigen	f	2026-01-29 17:04:20.024	\N	131070
1698816117637646041	1698814616177477294	Möbel und Böden schützen: Filzgleiter, Decken, Kartons	f	2026-01-29 17:04:22.46	\N	196605
1698816135438272218	1698814616177477294	Abschluss-/Übergabeprotokoll für alte Wohnung vorbereiten (Fotos planen)	f	2026-01-29 17:04:24.582	\N	262140
1698816150999140059	1698814616177477294	Zählerstände am Ab- und Einzugstag notieren und fotografieren	f	2026-01-29 17:04:26.437	\N	327675
1698816165914085084	1698814616177477294	Schlüssel für neue Wohnung abholen oder Übergabe bestätigen	f	2026-01-29 17:04:28.215	\N	393210
1698816178647992029	1698814616177477294	Recycling/ Sperrmülltermin für alte Wohnung planen	f	2026-01-29 17:04:29.733	\N	458745
1698816186919159518	1698814616177477294	Kinderbetreuung/Haustierbetreuung für Umzugstag organisieren	f	2026-01-29 17:04:30.719	\N	524280
1698816286047340255	1698814661870225072	Kühlschrank abtauen und reinigen (mind. 24–48 Std vorher ausräumen falls Gefrierfach)	f	2026-01-29 17:04:42.536	\N	65535
1698816304191899360	1698814661870225072	Letzte Wäsche waschen (Bettwäsche, Handtücher)	f	2026-01-29 17:04:44.699	\N	131070
1698816322193852129	1698814661870225072	Kleidung für Umzugstag/erste Tage einpacken (Reise-/Essentials-Koffer)	f	2026-01-29 17:04:46.845	\N	196605
1698816337310123746	1698814661870225072	Umzugshelfer nochmal bestätigen (Ort, Zeit, Parken, Verpflegung)	f	2026-01-29 17:04:48.648	\N	262140
1698816350899668707	1698814661870225072	Medikamente/ wichtige Unterlagen zusammenstellen	f	2026-01-29 17:04:50.267	\N	327675
1698816365973997284	1698814661870225072	Letzte Einkäufe: Küchenrolle, Putzmittel, Müllbeutel, Toilettenpapier, Grundnahrungsmittel	f	2026-01-29 17:04:52.064	\N	393210
1698816500376274661	1698814712545806002	Notfall- / Essentials-Kiste bereitstellen (siehe weiter unten)	f	2026-01-29 17:05:08.086	\N	65535
1698816543099455206	1698814712545806002	Elektronische Geräte sichern, Kabel beschriften	f	2026-01-29 17:05:13.179	\N	131070
1698816560606480103	1698814712545806002	Wertsachen/ Dokumente separat transportieren (z. B. in Handgepäck)	f	2026-01-29 17:05:15.266	\N	196605
1698816574045030120	1698814712545806002	Gebäude- und Wohnungsschlüssel sortieren & bereitlegen	f	2026-01-29 17:05:16.868	\N	262140
1698816588263720681	1698814712545806002	Letzte Reinigung auf alten Wohnungsflächen (wenn selbst gemacht)	f	2026-01-29 17:05:18.564	\N	327675
1698816601056347882	1698814712545806002	Zählerstände fotografieren (Strom, Gas, Wasser)	f	2026-01-29 17:05:20.088	\N	393210
1698816616508163819	1698814712545806002	Müll entsorgen, letzte Abfälle trennen	f	2026-01-29 17:05:21.93	\N	458745
1698816702105519852	1698814755361261236	Pünktlich vor Ort sein und Helfer einweisen	f	2026-01-29 17:05:32.134	\N	65535
1698816727757883117	1698814755361261236	Schweres zuerst: Möbel, große Geräte; Kartons dann gestapelt	f	2026-01-29 17:05:35.192	\N	131070
1698816741414536942	1698814755361261236	Treppenhaus-/Aufzugs-Schoner verwenden	f	2026-01-29 17:05:36.82	\N	196605
1698816799295932143	1698814755361261236	Übergabeprotokoll alte Wohnung mit Vermieter machen (Fotos, Mängel protokollieren)	f	2026-01-29 17:05:43.72	\N	262140
1698816815687272176	1698814755361261236	Zählerstände in neuer Wohnung fotografieren	f	2026-01-29 17:05:45.674	\N	327675
1698816831332026097	1698814755361261236	Möbel nach Plan aufstellen & wichtige Kartons zuerst öffnen	f	2026-01-29 17:05:47.54	\N	393210
1698816844762187506	1698814755361261236	Schlüsselübergabe abgeschlossen? Unterschriften sichern	f	2026-01-29 17:05:49.14	\N	458745
1698816857009555187	1698814755361261236	Verpflegung/Trinkpausen für Helfer einplanen	f	2026-01-29 17:05:50.6	\N	524280
1698816967487522548	1698814807269967542	Elektrik, Heizung, Wasser kontrollieren	f	2026-01-29 17:06:03.77	\N	65535
1698816983132276469	1698814807269967542	Internet/Telefonanschluss prüfen	f	2026-01-29 17:06:05.636	\N	131070
1698816997283858166	1698814807269967542	Postempfang prüfen (Nachsendeauftrag aktiv?)	f	2026-01-29 17:06:07.321	\N	196605
1698817086253434615	1698814807269967542	Erste Einkäufe erledigen (Lebensmittel, Haushaltsartikel)	f	2026-01-29 17:06:17.926	\N	262140
1698817116393703160	1698814807269967542	Müllentsorgung/ Wertstofftrennung für neuen Wohnort merken (Abfuhrzeiten)	f	2026-01-29 17:06:21.521	\N	327675
1698817134336935673	1698814807269967542	Offene Kartons systematisch auspacken (Priorität: Küche, Bad, Schlafzimmer)	f	2026-01-29 17:06:23.661	\N	393210
1698817148505294586	1698814807269967542	Anmeldung beim Einwohnermeldeamt (Ummeldung innerhalb gesetzlicher Frist)	f	2026-01-29 17:06:25.349	\N	458745
1698817165047629563	1698814807269967542	Einrichtungs- und Montageservice für große Möbel beauftragen (falls benötigt)	f	2026-01-29 17:06:27.322	\N	524280
1698817170919655164	1698814807269967542	Hausratversicherung abgeschlossen/angepasst? prüfen	f	2026-01-29 17:06:28.021	\N	589815
1698817307813349117	1698814875393853112	Adresse offiziell ummelden: Bank, Arbeitgeber, Steuer, Versicherungen, Krankenkasse, Kfz-Zulassung (falls nötig)	f	2026-01-29 17:06:44.338	\N	65535
1698817331477612286	1698814875393853112	Einwohnermeldeamt / Kfz / Rundfunkbeitrag (GEZ) / Wahlbenachrichtigung	f	2026-01-29 17:06:47.161	\N	131070
1698817344404457215	1698814875393853112	Nachsendezeit prüfen / wichtige Abos anpassen	f	2026-01-29 17:06:48.702	\N	196605
1698817358195328768	1698814875393853112	Nacharbeiten an Renovierung/kleinen Reparaturen erledigen	f	2026-01-29 17:06:50.346	\N	262140
1698817372539848449	1698814875393853112	Restliche Kartons auspacken und entsorgen	f	2026-01-29 17:06:52.056	\N	327675
1698817381205280514	1698814875393853112	Nachbarschaften kennenlernen (Hausverwaltung, Nachbarn, Müllplätze)	f	2026-01-29 17:06:53.089	\N	393210
1698818634815637258	1698814924425266874	Personalausweis / Reisepass, Mietvertrag, Übergabeprotokolle	f	2026-01-29 17:09:22.53	\N	65535
1698818650561054475	1698814924425266874	Geld, EC-/Kreditkarten	f	2026-01-29 17:09:24.408	\N	131070
1698818665769600780	1698814924425266874	Handy + Ladegerät / Powerbank	f	2026-01-29 17:09:26.221	\N	196605
1698818679627581197	1698814924425266874	Medikamente, Erste-Hilfe-Set	f	2026-01-29 17:09:27.873	\N	262140
1698818695104562958	1698814924425266874	Toilettenpapier, Handseife, Handtücher	f	2026-01-29 17:09:29.718	\N	327675
1698818718609442575	1698814924425266874	Basis-Kochutensilien: Wasserkocher, Kaffeefilter, Tassen, Besteck, Teller	f	2026-01-29 17:09:32.52	\N	393210
1698818731242686224	1698814924425266874	Kleidung für 1–2 Tage	f	2026-01-29 17:09:34.026	\N	458745
1698818752130320145	1698814924425266874	Taschenlampe, Multitool / Schraubenzieher, Hammer, Ersatzglühbirnen	f	2026-01-29 17:09:36.517	\N	524280
1698818767271757586	1698814924425266874	Schlüssel (alt & neu)	f	2026-01-29 17:09:38.321	\N	589815
1698818778554435347	1698814924425266874	Reinigungsmittel, Müllbeutel, Schwamm	f	2026-01-29 17:09:39.666	\N	655350
1698815120500590269	1698814492411954856	Kündigungsfrist für alte Wohnung beachten & schriftliche Kündigung (falls noch nicht geschehen)	t	2026-01-29 17:02:23.592	2026-01-29 17:13:23.753	131070
1813359991545923548	1813358839689381838	Zuordnung zu Versicherungen	f	2026-07-06 18:02:36.291	\N	65535
1813360104750188509	1813358839689381838	Tags integrieren	f	2026-07-06 18:02:49.784	\N	131070
1813360347466172382	1813358839689381838	Charts Anaylsen nach tags und Versicherungen	f	2026-07-06 18:03:18.717	\N	196605
1813363186338891752	1813362423428548581	Dokumente zu einem Inventar hochladen	f	2026-07-06 18:08:57.138	2026-07-06 18:09:09.226	65535
1813363407085111273	1813362423428548581	Bilder zu einem Inventar hochladen	f	2026-07-06 18:09:23.453	\N	131070
1813363728117139434	1813362423428548581	Notizen/Kommentare zu einem Inventar anlegen	f	2026-07-06 18:10:01.724	\N	196605
1813364467237390315	1813362423428548581	Das Datum der Garantie-Frist definieren und vor Ablauf Erinnerungs-Mail senden	f	2026-07-06 18:11:29.833	\N	262140
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, is_admin, name, username, phone, organization, subscribe_to_own_cards, created_at, updated_at, deleted_at, language, password_changed_at, avatar, is_sso) FROM stdin;
1452651665172726785	planka@cooolinho.de	$2b$10$EMwtSukzLRUa3/LEJa1ax.rxDZid15XOdj1tcQI.93oPzUDlcvCpu	t	Colin	cooolinho	\N	\N	t	2025-02-24 01:39:32.968	2026-04-15 00:46:51.371	\N	de-DE	\N	{"dirname": "9a0ea2bd-35be-4b68-ac9f-1aae5374e5d7", "extension": "jpg"}	f
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 34, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 1014, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: archive archive_from_model_original_record_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive
    ADD CONSTRAINT archive_from_model_original_record_id_unique UNIQUE (from_model, original_record_id);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_email_unique EXCLUDE USING btree (email WITH =) WHERE ((deleted_at IS NULL));


--
-- Name: user_account user_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_username_unique EXCLUDE USING btree (username WITH =) WHERE (((username IS NOT NULL) AND (deleted_at IS NULL)));


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_type_index ON public.action USING btree (type);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_card_id_index ON public.task USING btree (card_id);


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

